import javafx.application.Application;
import javafx.stage.Stage;
import view.ViewDispatcher;

public class Main extends Application{

	public static void main(String[] args){
		
		launch(args);
	

	}

	@Override
	public void start(Stage stage) throws Exception {
	   
		ViewDispatcher dispatcher = ViewDispatcher.getIstance();
		dispatcher.login(stage);
		stage.show();
	}

}
