package utility;

public class Utility {

	
	
	
	public static void waitForOneSecond() {
		
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}
}




