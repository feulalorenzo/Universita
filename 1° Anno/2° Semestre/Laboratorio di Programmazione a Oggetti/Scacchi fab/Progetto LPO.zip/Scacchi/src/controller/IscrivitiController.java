package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import domain.DataInitializable;
import domain.Utente;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import view.ViewDispatcher;

public class IscrivitiController implements Initializable, DataInitializable<Utente>{

	
	@FXML
	private TextField username = new TextField();
	
	@FXML
	private PasswordField password = new PasswordField();
	
	@FXML
	private PasswordField confermaPassword = new PasswordField();
	
	@FXML
	private Button avanti = new Button();
	
	@FXML
	private Button annulla = new Button();
	
	
	
	private Utente utente;
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		avanti.disableProperty().bind(username.textProperty().isEmpty().or(password.textProperty().isEmpty().or(confermaPassword.textProperty().isEmpty())));
		
	}

	
	@Override
	public void initializeData(Utente param) {
		this.utente = param;
	}
	
	
	public void avanti() {
		utente.setUsername(username.getText());
		utente.setPassword(password.getText());
		
		try {
			dispatcher.home("home",utente );
		} catch (IOException e) {
			
		}
	}
	
	public void annulla() {
		
		try {
			dispatcher.login();
		} catch (IOException e) {

			System.out.println("Non è stato possibile tornare al login da password dimenticata");
		}
	}
}
