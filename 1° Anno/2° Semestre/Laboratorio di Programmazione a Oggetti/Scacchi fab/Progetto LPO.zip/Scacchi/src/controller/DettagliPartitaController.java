package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import domain.DataInitializable;
import domain.Esito;
import domain.Partita;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import view.ViewDispatcher;

public class DettagliPartitaController implements Initializable, DataInitializable<Partita> {

	
	@FXML
	private Label giocatoreBianco = new Label();
	
	@FXML
	private Label giocatoreNero = new Label();
	
	@FXML
	private Label statoPartita = new Label();
	
	@FXML
	private Label vincitorePartita = new Label();

	@FXML
	private VBox listaMossePartita = new VBox();
	
	@FXML
	private Button carica = new Button();
	
	
	private Partita partita;
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}

	
	
	@Override
	public void initializeData(Partita param) {
		this.partita = param;
		
		Esito esitoPartita = partita.getEsito();
		
		giocatoreBianco.setText(partita.getWhitePlayer().getUsername());
		giocatoreNero.setText(partita.getBlackPlayer().getUsername());
		statoPartita.setText(esitoPartita.toString());
		
		if(esitoPartita == Esito.TERMINATA) {
			vincitorePartita.setText(partita.getVincitore().getUsername());
		}
		else {
			vincitorePartita.setText("-");
		}
		
		String elencoMosse = "";
		/*for(Mossa mossa : partita.getListaMosse()) {
			
			elencoMosse += "  -  " + mossa.toString();
		}
		
		listaMossePartita.setText(elencoMosse);*/
		
		if(esitoPartita != Esito.SOSPESA) {
			carica.setVisible(false);
		}
	}
	
	
	
	
	
	public void carica() {
		
		try {
			partita.setEsito(null);
			dispatcher.switchGeneralView("partita", partita);
		} 
		catch (IOException e) {
			
			System.out.println("Non è possibile caricare questa partita");
		}
		
	}
}
