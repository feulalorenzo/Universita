package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import domain.DataInitializable;
import domain.Utente;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import view.ViewDispatcher;

public class LoginController implements Initializable, DataInitializable<String>{

	@FXML
	private TextField username = new TextField();
	
	@FXML
	private PasswordField password = new PasswordField();
	
	@FXML
	private Hyperlink passwordDimenticata = new Hyperlink();
	
	@FXML
	private Button avanti = new Button();
	
	@FXML
	private Label errorLabel = new Label();
	
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
			
		
		
		
	}

	public void login() {
		Utente utente = new Utente();
		utente.setUsername(username.getText());
		utente.setPassword(password.getText());
		try {
			
			dispatcher.home("home",utente);
		} catch (IOException e) {
			
			errorLabel.setText("Username o Password errati!");
		}
		
	}
	
	
	public void passwordDimenticata() {
		
		try {
			Utente utente = new Utente();
			dispatcher.passwordDimenticata("passworddimenticata", utente);
		}
		catch(IOException e) {
			
			System.out.println("Non è stato possibile cambiare password in logincontroller");
		}
	}
	
	public void iscriviti() {
		
		try {
			Utente utente = new Utente();
			dispatcher.passwordDimenticata("iscriviti", utente);
		}
		catch(IOException e) {
			
			System.out.println("Non è stato possibile cambiare password in logincontroller");
		}
	}
}
