package controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import domain.Casella;
import domain.Colore;
import domain.Computer;
import domain.DataInitializable;
import domain.Esito;
import domain.Mossa;
import domain.Partita;
import domain.Pezzo;
import domain.ScacchiFacade;
import domain.Scacchiera;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import utility.Utility;
import view.ViewDispatcher;

public class PartitaController implements Initializable, DataInitializable<Partita>{

	
	
	@FXML
	private GridPane grid = new GridPane();
	
	@FXML
	private Label nomeGN = new Label();
	
	@FXML
	private Label nomeGB = new Label();
	
	@FXML
	private VBox  vboxMosse = new VBox();
	
	@FXML
	private ImageView annullaMossa = new ImageView();
	
	@FXML
	private Button pauseButton = new Button();
	
	@FXML
	private Button quitBianco = new Button();
	
	@FXML
	private Button quitNero = new Button();
	
	private Partita partita;
	
	private Mossa mossa = new Mossa();
	
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	
	
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}

	
	@Override
	public void initializeData(Partita param) {
		
		this.partita = param;
		
		//INSERIMENTO DEI NOMI DEI GIOCATORI
		nomeGB.setText(partita.getWhitePlayer().getUsername());
		nomeGN.setText(partita.getBlackPlayer().getUsername());
		
		
		//COSTRUZIONE DELLA SCACCHIERA GRAFICA
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				Button button = createButton(i,j,partita.getScacchiera().getPezzo(new Casella(i,j)));				
				grid.add(button, j, i);
			}
		}
		
		//INSERIMENTO CRONOLOGIA MOSSE
		updateVboxMosse();	
		
		
	}
	
	
	

	
	
	
	private ImageView loadChessImageView(Pezzo pezzo) {
		ImageView imageViewResult = new ImageView();
		
		//DIMENSIONI IMMAGINE PEZZO SCACCHI
		imageViewResult.setFitHeight(80);
		imageViewResult.setFitWidth(80);
		
		//ACQUISIZIONE IMMAGINE PEZZO SCACCHI
		if(pezzo != null) {
			imageViewResult = new ImageView(new Image(getClass().getResourceAsStream("/viste/" + pezzo.getCod() + ".png")));	
		}
		
		return imageViewResult;
	}
	
	private Button createButton(int i, int j, Pezzo pezzo) {
        
		Scacchiera scacchiera = this.partita.getScacchiera();
		
		ImageView imageView = loadChessImageView(pezzo);
 
		Button button = new Button();
				
		//IMPOSTA LO STILE DEL BOTTONE		
		button.setStyle("-fx-background-color: trasparent");
		button.setGraphic(imageView);
		button.setContentDisplay(ContentDisplay.TOP);
		button.setPrefWidth(88);
		button.setPrefHeight(88);
		
		
		
		//FUNZIONE BOTTONE
		button.setOnMouseClicked((MouseEvent event) ->{
			
			Casella casella = new Casella(i,j);
			
			
			/*if(mossa.getPartenza() == null) {
				mossa.setPartenza(casella);
				mossa.setPezzo(scacchiera.getPezzo(casella));
				
				
			}
			else {
				mossa.setArrivo(casella);
				mossa.setCatturato(scacchiera.getPezzo(casella));
				
				if(partita.effettuaMossa(mossa)) {
				
					//AGGIORNAMENTO GRAFICO
				    updateVboxMosse();
				    movePiece(mossa.getPartenza(), mossa.getArrivo());
				    
				    
				    mossa = new Mossa();
				}
				
				else {
					mossa.setPartenza(casella);
				}
				
			}*/
					
	});
						
		return button;
		
	}
	
	private Button getButtonBySquare(Casella casella) {
		Button button = new Button();
		for(Node nodo: grid.getChildren()) {
			if(grid.getRowIndex(nodo) == casella.getX() && grid.getColumnIndex(nodo) == casella.getY()) {
				button = (Button)nodo;
				break;
			}
		}
		return button;
		
	}
		
	private void movePiece(Casella partenza, Casella arrivo) {
		
		Button bottonePartenza = getButtonBySquare(partenza);
		Button BottoneArrivo = getButtonBySquare(arrivo);
		
		BottoneArrivo.setGraphic((ImageView)bottonePartenza.getGraphic());
		bottonePartenza.setGraphic(new ImageView());
		
	}
    	
	private void updateVboxMosse() {
		vboxMosse.getChildren().clear();
		
		// CREA L'ETICHETTA CHE RAPPRESENTA LA MOSSA
			
		for(Mossa mossa: partita.getListaMosse()) {
			Label etichettaMossa = new Label();
			etichettaMossa.setStyle("-fx-font-size: 16; -fx-font-weight: bold;");
			etichettaMossa.setText("- " + mossa.toString());
			vboxMosse.getChildren().add(etichettaMossa);
		}		
	}
	
	public void partitaTerminata() {
		
		try {
			dispatcher.switchGeneralView("esitopartita", partita);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void annullaMossa() {
		
		Mossa mossa = partita.undoLastMove();
		
		if(mossa != null) {
			//RICREO LA SITUAZIONE ALL'INTERNO DELLA SCACCHIERA
			partita.getScacchiera().undo(mossa);
			
			//RISTEMA GRAFICAMENTE LA SCACCHIERA
			movePiece(mossa.getArrivo(), mossa.getPartenza()); //RIPORTO INDIETRO IL PEZZO MOSSO

			if(partita.getScacchiera().getPezzo(mossa.getArrivo()) != null) { //RIPOSIZIONO UN EVENTUALE PEZZO MANGIATO
				Button arrivoDaRipristinare = getButtonBySquare(mossa.getArrivo());				
				ImageView imagePezzoMangiato = loadChessImageView(mossa.getCatturato());
				arrivoDaRipristinare.setGraphic(imagePezzoMangiato);
			}
			
			//AGGIORNO LA LISTA DELLE MOSSE EFFETTUATE
			updateVboxMosse();
		}
		
	}

    public void quitBianco() {
    	partita.setEsito(Esito.TERMINATA);
    	partita.setVincitore(partita.getBlackPlayer());
    	
    	try {
			dispatcher.switchGeneralView("esitopartita", partita);
		} catch (IOException e) {
			
			System.out.println("Non è possibile caricare la vista esitopartita in partiacontrollore - quit");
		}
    }
    
    public void quitNero() {
    	partita.setEsito(Esito.TERMINATA);
    	partita.setVincitore(partita.getWhitePlayer());
    	
    	try {
			dispatcher.switchGeneralView("esitopartita", partita);
		} catch (IOException e) {
			
			System.out.println("Non è possibile caricare la vista esitopartita in partiacontrollore - quit");
		}
    	
    }
       
    public void pause() {
    	partita.setEsito(Esito.SOSPESA);
    	
    	try {
			dispatcher.switchGeneralView("esitopartita", partita);
		} catch (IOException e) {
			
			System.out.println("Non è possibile caricare la vista esitopartita in partiacontrollore - pause");
		}
    }

}
