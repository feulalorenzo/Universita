package controller;

import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;

import domain.Colore;
import domain.DataInitializable;
import domain.Partita;
import domain.Scacchiera;
import domain.Utente;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import view.ViewDispatcher;

public class SecondoGiocatoreController implements Initializable, DataInitializable<Utente>{

	
	@FXML
	private TextField nomeG2 = new TextField();
	
	@FXML
	private Button avanti = new Button();
	
	
	
	private Utente utente;
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
		
	}
	
	
	@Override
	public void initializeData(Utente param) {
		this.utente = param;
	}

	
	
	public void avanti() {
		
		Utente g2 = new Utente();
		g2.setUsername(nomeG2.getText());
		
		//DIAMO I COLORI AI GIOCATORI
		if(new Random().nextInt(2) == 0) {
			utente.setColore(Colore.BIANCO);
			g2.setColore(Colore.NERO);
		}
		else {
			utente.setColore(Colore.NERO);
			g2.setColore(Colore.BIANCO);
		}
		
		//CREAIAMO E SETTIAMO UNA NUOVA PARTITA
		Partita partita = new Partita();
		
		partita.setG1(utente);
		partita.setG2(g2);
		partita.setScacchiera(new Scacchiera());
		
		
		
		try {
			dispatcher.switchGeneralView("partita", partita);
		} catch (IOException e) {
			System.out.println("Non è stato possibile avviare una nuova partita");
		}
		
	}
}
