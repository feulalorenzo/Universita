package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import domain.DataInitializable;
import domain.Utente;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import view.ViewDispatcher;

public class HomeController implements Initializable, DataInitializable<Utente>{

	
	
	@FXML
	private Label username = new Label();
	
	@FXML
	private Label errorLabel = new Label();
	
	@FXML
	private Button nuovaPartita = new Button();
	
	@FXML
	private Button caricaPartita = new Button();
	
	@FXML
	private ImageView logout = new ImageView();
	
	
	
	private Utente utente;
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	
		
	}

	
	@Override
	public void initializeData(Utente param) {
		this.utente = param;
		
		username.setText(utente.getUsername());
		
	}
	
	
	public void nuova() {
		
		try {
			dispatcher.switchView("sceltamod", utente);
		} catch (IOException e) {
			
		    System.out.println("Non è stato possibile caricare la vista");
		}
	}
	
	public void carica() {
		
		try {
			dispatcher.switchView("caricapartita", utente);
				
		}catch(IOException e) {
			System.out.println("Non è stato possibile caricare la vista per le partite fatte");
		}
	}
	
	public void logout() {
		
		try {
			dispatcher.login();
		}
		catch(IOException e) {
			System.out.println("Non è stato possibile fare il logout in homeController");
		}
	}
	
	
}
