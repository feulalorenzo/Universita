package controller;

import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;

import domain.Colore;
import domain.Computer;
import domain.DataInitializable;
import domain.Partita;
import domain.Scacchiera;
import domain.Utente;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import view.ViewDispatcher;

public class SceltaModController implements Initializable, DataInitializable<Utente> {

	
	
	@FXML
	private Button mod1 = new Button();
	
	
	@FXML
	private Button mod2 = new Button();
	
	
	private Utente utente;
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}
	
	@Override
	public void initializeData(Utente param) {
		this.utente = param;
		
	}
	
	
	
	public void mod1() {
		
		try {
			dispatcher.switchView("secondogiocatore",utente);
		} catch (IOException e) {
			System.out.println("Non è stato possibile andare alla scelta del secondo utente");
		}
	}
	
	public void mod2() {
		Computer computer = Computer.getIstance();
		
		Partita partita = new Partita();
		Scacchiera scacchiera = new Scacchiera();
		
		
		if(new Random().nextInt(2) == 0) {
			utente.setColore(Colore.BIANCO);
			computer.setColore(Colore.NERO);
		}
		else {
			utente.setColore(Colore.NERO);
			computer.setColore(Colore.BIANCO);
		}
		
		
		partita.setG1(utente);
		partita.setG2(computer);
		partita.setScacchiera(scacchiera);
		
		try {
			dispatcher.switchGeneralView("partita", partita);
			
		}
		catch(IOException e) {
			System.out.println("Non è stata possibile avviare una partita con il computer");
		}
	}
	

}
