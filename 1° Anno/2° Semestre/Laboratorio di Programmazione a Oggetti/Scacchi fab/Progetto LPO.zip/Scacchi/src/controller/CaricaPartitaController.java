package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.ResourceBundle;

import domain.DataInitializable;
import domain.Esito;
import domain.OrderByMoveNumber;
import domain.OrderByPiecesNumber;
import domain.OrderByPiecesValue;
import domain.Partita;
import domain.Scacchiera;
import domain.Utente;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import view.ViewDispatcher;

public class CaricaPartitaController implements Initializable, DataInitializable<Utente> {

	
	@FXML
	private VBox listaPartite = new VBox();
	
	
	@FXML
	private Button tutte = new Button();
	
	@FXML
	private Button terminate = new Button();
	
	@FXML
	private Button sospeso = new Button();
	
	@FXML
	private RadioButton numeroMosse = new RadioButton();
	
	@FXML
	private RadioButton numeroPezzi = new RadioButton();
	
	@FXML
	private RadioButton valorePezzi = new RadioButton();
	
	
	private Utente utente;
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	private List<Partita> partite = new ArrayList<>();
	private int guardia;
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		ToggleGroup tg = new ToggleGroup();
		numeroMosse.setToggleGroup(tg);
		numeroPezzi.setToggleGroup(tg);
		valorePezzi.setToggleGroup(tg);
		
		numeroMosse.setOnMouseClicked((MouseEvent event) ->{
			
			
			Collections.sort(partite, new OrderByMoveNumber());

		});
		
		numeroPezzi.setOnMouseClicked((MouseEvent event) ->{
			
			Collections.sort(partite, new OrderByPiecesNumber());

		});

		valorePezzi.setOnMouseClicked((MouseEvent event) ->{
	
			
			Collections.sort(partite, new OrderByPiecesValue());

		});
		
		
		
	}
	
	@Override
	public void initializeData(Utente param) {
		this.utente = utente;
		partite = new ArrayList<>();
				
		
		Partita p = new Partita();
		p.setEsito(Esito.PATTA);

		partite.add(p);
		
		 p = new Partita();
		p.setEsito(Esito.TERMINATA);

		partite.add(p);
		
		
		 p = new Partita();
		p.setEsito(Esito.SOSPESA);

		partite.add(p);
		
		
		 p = new Partita();
		p.setEsito(Esito.SOSPESA);

		partite.add(p);
		
		viewTutte();
		
		
		
		
		
		
		
	}
	

	public HBox createRow(Partita p) {
		
		HBox result = new HBox();
		
		//CREAZIONE DI UN PANE
		Pane pane = new Pane();
		
		//SETTAGGIO STILE PANE
		pane.setPrefWidth(750);
		
		
		//CREAZIONE LABEL PER IL NOME DELLA CANZONE
		Label nomePartita = new Label(" -  " + Integer.toString(p.getId()));		
		
		//SETTAGGIO STILE LABEL
		nomePartita.setStyle("-fx-font-size: 16");
		
		
		
		//CREAZIONI BOTTONE PER CARICARE UNA PARTITA
        Button carica = new Button("Carica");
		carica.setStyle("-fx-background-color:  #94e685; -fx-font-size: 14 ;-fx-border-color: white;");
		carica.setPrefWidth(100);
		
		if(p.getEsito() != Esito.SOSPESA) carica.setVisible(false);
		else carica.setOnAction((ActionEvent event) ->{
			
			
				try {
					dispatcher.switchGeneralView("partita",p);
				}
				catch (IOException e) {
					System.out.println("Non è stato possibile carica la partita");
				}
			
			
		});
		
		
		//CREAZIONE BOTTONE PER VISUALIZZARE I DATI DI UNA PARTITA
		Button dettagli = new Button("Dettagli");
		dettagli.setStyle("-fx-background-color:  #94e685;-fx-font-size: 14; -fx-border-color: white;");
		dettagli.setPrefWidth(100);
		dettagli.setOnAction((ActionEvent event) ->{
			
			try {
				dispatcher.switchView("dettagli", p);
			} catch (IOException e) {
				System.out.println("Non è ancora stata creata la vista dettagli.fxml");
			}
		});
		
		
		
		
		
		pane.getChildren().add(nomePartita);
		result.getChildren().add(pane);
		result.getChildren().add(carica);
		result.getChildren().add(dettagli);
		
		return result;
	}
	
	
	public void viewTutte() {
		listaPartite.getChildren().clear();
		for(Partita p : partite) {
			listaPartite.getChildren().add(createRow(p));
			Separator s = new Separator();
			listaPartite.getChildren().add(s);
		}
		guardia = 0;
	}	
	public void viewTerminate() {
		listaPartite.getChildren().clear();
		for(Partita p: partite) {
			if(p.getEsito() == Esito.PATTA || p.getEsito() == Esito.TERMINATA) {
				listaPartite.getChildren().add(createRow(p));
				Separator s = new Separator();
				listaPartite.getChildren().add(s);
			}
		}
		guardia = 1;
	}
	public void viewSospese() {
		listaPartite.getChildren().clear();
		for(Partita p: partite) {
			if(p.getEsito() == Esito.SOSPESA) {
				listaPartite.getChildren().add(createRow(p));
				Separator s = new Separator();
				listaPartite.getChildren().add(s);
			}
		}
		
		guardia = 2;
	}
	
}
