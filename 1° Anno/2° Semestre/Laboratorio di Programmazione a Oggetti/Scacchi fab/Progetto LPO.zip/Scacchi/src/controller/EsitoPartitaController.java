package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import domain.DataInitializable;
import domain.Partita;
import domain.Utente;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import view.ViewDispatcher;

public class EsitoPartitaController implements Initializable, DataInitializable<Partita>{

	@FXML
	private Label indicatoreEsitoPartita = new Label();
	
	@FXML
	private Button tornaAlMenu = new Button();
	
	
	@FXML
	private Button dettagliPartita = new Button();
	
	
	
	private Partita partita;
	private ViewDispatcher dispatcher = ViewDispatcher.getIstance();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}
	
	
	@Override
	public void initializeData(Partita param) {
		this.partita = param;
		
		switch(partita.getEsito()) {
		
		case PATTA:
			indicatoreEsitoPartita.setText("Pareggio");
			break;
		case SOSPESA:
			indicatoreEsitoPartita.setText("Sospesa");
			break;
		case TERMINATA:
			indicatoreEsitoPartita.setText("Terminata");
			break;
		}
		
		
	}
	
	
	
	public void tornaAlMenu() {

		try {
			dispatcher.home("home",(Utente)partita.getG1());
		} catch (IOException e) {
			
			System.out.println("Non è possibile tornare al menu da esitoPartitaController");
		}
		
	}
	
	public void dettagliPartita() {
		
		try {
			dispatcher.home("home",(Utente)partita.getG1());
			dispatcher.switchView("dettagli", partita);
		} catch (IOException e) {
			
			System.out.println("Non è possibile andare ai dettagli da esitoPartitaController");
		}
	}

}
