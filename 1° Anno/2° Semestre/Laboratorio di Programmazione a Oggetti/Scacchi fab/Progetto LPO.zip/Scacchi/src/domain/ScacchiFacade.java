package domain;

import javax.crypto.spec.PSource;

public class ScacchiFacade {

	
	
	
	public static boolean effettuaMossa(Scacchiera scacchiera, Mossa mossa, Colore colore) {
		if(!(isValidMove(scacchiera, mossa, colore))) return false;
		if(!(isValidMovement(scacchiera,mossa,colore))) return false;
		if(!(isFreeWay(scacchiera,mossa))) return false;
		if(isScaccoAfterMove(scacchiera, mossa, colore)) return false;
		mossa.setCatturato(scacchiera);
		return true;
	}
	
	public static boolean isScacco(Scacchiera scacchiera, Colore colore) {
		
		Casella posizioneRe = scacchiera.getKingPosition(colore);
		
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				
				Casella casella = new Casella(i,j);
				Pezzo pezzo = scacchiera.getPezzo(casella);
				
				if(pezzo != null && pezzo.getColore() != colore) {
					
					Mossa mossa = new Mossa();
					mossa.setPartenza(casella);
					mossa.setArrivo(posizioneRe);
					mossa.setPezzo(pezzo);
					
					if(isValidMovement(scacchiera, mossa, colore == Colore.BIANCO ? Colore.NERO : Colore.BIANCO) &&
							isFreeWay(scacchiera, mossa)) {
						return true;
					}
				}
			}
		}
		
		return false;
	}
	
	public static boolean isScaccoMatto(Scacchiera scacchiera, Colore colore) {
		
		if(canKingMove(scacchiera, colore) || canPieceDefendKing(scacchiera, colore)) return false;
		return true;
	}
	
	public static boolean isScaccoAfterMove(Scacchiera scacchiera, Mossa mossa, Colore colore) {
		Scacchiera s = new Scacchiera();
		s.copy(scacchiera);
		s.moveTo(mossa.getPartenza(), mossa.getArrivo());
		return isScacco(s,colore); 
	}
	
	public static boolean isValidMove(Scacchiera scacchiera, Mossa mossa, Colore colore) {
		
		Casella partenza = mossa.getPartenza();
		Casella arrivo = mossa.getArrivo();
		Pezzo pezzoPartenza = scacchiera.getPezzo(partenza);
		Pezzo pezzoArrivo = scacchiera.getPezzo(arrivo);
		
		//CONTROLLA SE LA CASELLA DI ARRIVO E DI PARTENZA SIANO VALIDE
		if(!(partenza.isValid() && arrivo.isValid())) return false;
		
		//CONTROLLA CHE NON COINCIDANO
		if(partenza.equals(arrivo)) return false;
		
		//CONTROLLA CHE CI SIA UN PEZZO NELLA CASELLA DI PARTENZA
		if(pezzoPartenza == null) return false;
		
		//CONTROLLA CHE NON CI SIA UN PEZZO DELLO STESSO COLORE NELLA CASELLA ARRIVO
		if(pezzoArrivo != null && pezzoPartenza.getColore() == pezzoArrivo.getColore()) return false;
		
		//CONTROLLA CHE IL PEZZO CHE SI STIA SPOSTANDO SIA DEL GIOCATORE DI TURNO
		if(pezzoPartenza.getColore() != colore) return false;
		
		return true;
	
	}
	
	public static boolean isValidMovement(Scacchiera scacchiera, Mossa mossa, Colore colore) {
		
		int deltaX = Math.abs(mossa.getArrivo().getX() - mossa.getPartenza().getX());
	    int deltaY = Math.abs(mossa.getArrivo().getY() - mossa.getPartenza().getY());
	    
	    TipoPezzo tipoPezzo = scacchiera.getPezzo(mossa.getPartenza()).getTipo();
	    
	    if(tipoPezzo == TipoPezzo.ALFIERE || tipoPezzo == TipoPezzo.REGINA) {
	    	
	    	if(deltaX == deltaY) return true;
	    }
		
	    
	    if(tipoPezzo == TipoPezzo.TORRE || tipoPezzo == TipoPezzo.REGINA) {
	    	
	    	if(deltaX == 0 && deltaY > 0 || deltaX > 0 && deltaY == 0) return true;
	    }
	    
	    if(tipoPezzo == TipoPezzo.RE) {
	    	
	    	if(deltaX <= 1 && deltaY <= 1) return true;
	    }
	    
	    if(tipoPezzo == TipoPezzo.CAVALLO) {
	    	
	    	if ((deltaX == 2 && deltaY == 1) || (deltaX == 1 && deltaY == 2)) return true;
	    }
	    
	    if(tipoPezzo == TipoPezzo.PEDONE) {
	    	
	    	int direzione = (colore == Colore.BIANCO ? 1 : -1);
	    	int differenza = mossa.getArrivo().getX() - mossa.getPartenza().getX();
	    	Pezzo pezzoArrivo = scacchiera.getPezzo(mossa.getArrivo());
	    	
	    	//CONTROLLA CHE IL PEDONE NON SI MUOVA ALL'INDIETRO
	    	if((direzione == 1 && differenza > 0) || (direzione == -1 && differenza < 0)) return false;
	            	
	    	//CONTROLLA CHE IL PEDONE POSSA MUOVERSI IN AVANTI
	    	if(deltaX == 1 && deltaY == 0 && pezzoArrivo == null) return true;
	    	
	    	//CONTROLLA CHE IL PEDONE POSSA MUOVERSI IN AVANTI DI 2 AL PRIMO TURNO (DA CONTROLLARE)
	    	if((deltaX == 2 && deltaY == 0) && mossa.getPartenza().getX() == (colore == Colore.BIANCO ? 6 : 1)) return true;
	    	
	    	//CONTROLLA CHE IL PEDONE POSSA MANGIARE IN DIAGONALE
	    	if((deltaX == 1 && deltaY == 1) && pezzoArrivo != null && pezzoArrivo.getColore() != colore) return true;
	    	
	    	
	    }
	    return false;
		
		
	}

	public static boolean isFreeWay(Scacchiera scacchiera, Mossa mossa){
	    Casella partenza = mossa.getPartenza();
	    Casella arrivo = mossa.getArrivo();
	    TipoPezzo tipoPezzo = scacchiera.getPezzo(partenza).getTipo();

	    if (tipoPezzo == TipoPezzo.ALFIERE || tipoPezzo == TipoPezzo.REGINA) {
	        int deltaX = Math.abs(arrivo.getX() - partenza.getX());
	        int deltaY = Math.abs(arrivo.getY() - partenza.getY());

	        if (deltaX == deltaY) {
	            // MOVIMENTO IN DIAGONALE
	            int deltaXSign = Integer.compare(arrivo.getX(), partenza.getX());
	            int deltaYSign = Integer.compare(arrivo.getY(), partenza.getY());

	            int x = partenza.getX() + deltaXSign;
	            int y = partenza.getY() + deltaYSign;

	            // CONTROLLA SE CI SONO PEZZI NEL MEZZO DEL CAMMINO DELL'ALFIERE O DELLA REGINA
	            while (x != arrivo.getX() && y != arrivo.getY()) {
	                if (scacchiera.getPezzo(new Casella(x, y)) != null) {
	                    return false; // CI SONO PEZZI NEL MEZZO
	                }
	                x += deltaXSign;
	                y += deltaYSign;
	            }
	        }
	    }

	    if (tipoPezzo == TipoPezzo.TORRE || tipoPezzo == TipoPezzo.REGINA) {
	        int deltaX = Math.abs(arrivo.getX() - partenza.getX());
	        int deltaY = Math.abs(arrivo.getY() - partenza.getY());

	        if (deltaX > 0 && deltaY == 0) {
	        	
	            // MOVIMENTO IN ORIZZONTALE (COME UNA TORRE O REGINA)
	            int minX = Math.min(partenza.getX(), arrivo.getX()) + 1;
	            int maxX = Math.max(partenza.getX(), arrivo.getX());
	            int y = partenza.getY();

	            for (int i = minX; i < maxX; i++) {
	                if (scacchiera.getPezzo(new Casella(i, y)) != null) {
	                    return false; // CI SONO PEZZI NEL MEZZO
	                }
	            }
	        } else if (deltaX == 0 && deltaY > 0) {
	        	
	            // MOVIMENTO IN VERTICALE (COME UNA TORRE O REGINA)
	            int minY = Math.min(partenza.getY(), arrivo.getY()) + 1;
	            int maxY = Math.max(partenza.getY(), arrivo.getY());
	            int x = partenza.getX();

	            for (int i = minY; i < maxY; i++) {
	                if (scacchiera.getPezzo(new Casella(x, i)) != null) {
	                    return false; // CI SONO PEZZI NEL MEZZO
	                }
	            }
	        }
	    }

	    return true;
	}

	public static boolean canKingMove(Scacchiera scacchiera, Colore colore) {
		
		Casella posizioneRe = scacchiera.getKingPosition(colore);
		
		for(int i = -1; i <= 1; i++) {
			for(int j = -1; j <= 1; j++) {
				
				Casella casella = new Casella(posizioneRe.getX() + i, posizioneRe.getY() + j);
				
				if(casella.isValid()) {
				Mossa mossa = new Mossa();
				mossa.setPartenza(posizioneRe);
				mossa.setArrivo(casella);
				mossa.setPezzo(scacchiera.getPezzo(posizioneRe));
				
				if(isValidMove(scacchiera, mossa, colore) && isValidMovement(scacchiera, mossa, colore) && isFreeWay(scacchiera, mossa)) {
					
					if(!(isScaccoAfterMove(scacchiera, mossa, colore))) return true;
				}
				
				}
			}
		}
		return false;
	}

    public static boolean canPieceDefendKing(Scacchiera scacchiera, Colore colore) {
    	
    	Casella posizioneRe = scacchiera.getKingPosition(colore);
    	
    	for(int i = 0; i < 8; i++) {
    		for(int j = 0; j < 8; j++) {
    			
    			Casella partenza = new Casella(i,j);
    			Pezzo pezzo = scacchiera.getPezzo(partenza);
    			if(pezzo != null && pezzo.getColore() == colore) {
    				
    				
    				for(int x = 0; x < 8; x++) {
    					for(int y = 0; y < 8; y++) {
    						
    						Casella arrivo = new Casella(x,y); 
    						
    						Mossa mossa = new Mossa();
    						mossa.setPartenza(partenza);
    						mossa.setArrivo(arrivo);
    						mossa.setPezzo(pezzo);
    						
    						if(isValidMove(scacchiera, mossa, colore) && isValidMovement(scacchiera, mossa, colore) && isFreeWay(scacchiera, mossa)) {
    							
    							if(!(isScaccoAfterMove(scacchiera, mossa, colore))) return true;
    						}
    					}
    				}
    			}
    		}
    	}
    	return false;
    }

    
}
