package domain;

import java.util.Comparator;

public class OrderByMoveNumber implements Comparator<Partita>{

	@Override
	public int compare(Partita p1, Partita p2) {
		if(p1.getNumeroMosse() > p2.getNumeroMosse()) return 1;
		else if(p1.getNumeroMosse() < p2.getNumeroMosse()) return -1;
		return 0;
	}

}
