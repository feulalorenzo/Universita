package domain;

public class Pezzo {

	private TipoPezzo tipo;
	private Colore colore;
	
	public Pezzo() {}
	

	public Pezzo(TipoPezzo p, Colore c) {
		this.tipo = p;
		this.colore = c;
	}
	
	public TipoPezzo getTipo() {
		return this.tipo;
	}
	public void setTipo(TipoPezzo p) {
		this.tipo = p;
		
	}
	
	
	public Colore getColore() {
		return this.colore;
	}
	public void setColore(Colore c) {
		this.colore = c;
	}
	public int getValore() {
		
		switch (this.tipo){
		case PEDONE:
			return 1;
		case CAVALLO:
			return 3;
		case ALFIERE:
			return 3;
		case TORRE:
			return 5;
		case REGINA:
			return 9;
		}
		return 0;
	}
	
	
	public String getCod() {
		String result = (colore == Colore.BIANCO) ? "b" : "n";
		
		if (tipo == TipoPezzo.TORRE) {
	        result += "_t";
	    } 
		else if (tipo == TipoPezzo.CAVALLO) {
	        result += "_c";
	    } 
	    else if (tipo == TipoPezzo.ALFIERE) {
	        result += "_a";
	    } 
	    else if (tipo == TipoPezzo.REGINA) {
	        result += "_q";
	    } 
	    else if (tipo == TipoPezzo.RE) {
	        result += "_k";
	    } 
	    else if(tipo == TipoPezzo.PEDONE){
	        result += "_p";
	    } 
		
		return result;
	}

    	

}
