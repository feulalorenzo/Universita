package domain;

public class Mossa {

	private Pezzo pezzo;
	private Casella partenza;
	private Casella arrivo;
	private Pezzo catturato;
	
	public Mossa() {}
	
	
	public Pezzo getPezzo() {
		return this.pezzo;
	}	
	
	public void setPezzo(Pezzo p) {
		this.pezzo =p;
	}
	
	public Casella getPartenza() {
		return this.partenza;
	}
	
	public void setPartenza(Casella c) {
		this.partenza = c;
	}
	
	public Casella getArrivo() {
		return this.arrivo;
	}
	
	public void setArrivo(Casella c) {
		this.arrivo = c;
	}
	
	public Pezzo getCatturato() {
		return this.catturato;
	}
	
	public void setCatturato(Pezzo catturato) {
		this.catturato = catturato;
	}
	
	public void setCatturato(Scacchiera scacchiera) {
		Pezzo pezzo = scacchiera.getPezzo(arrivo);
		if(pezzo != null) this.catturato = pezzo;
			
	}
	
	public boolean hasCaptured() {
		if (this.catturato != null) return true;
		
		return false;
	}
	
    
    @Override
    public String toString() {
    	String result = this.getPezzo().getCod();
    	
    	switch(this.getArrivo().getX()) {
    	
    	case 0:
    		result += "a";
    		break;
    	case 1:
    		result += "b";
    		break;
    	case 2:
    		result += "c";
    		break;
    	case 3:
    		result += "d";
    		break;
    	case 4:
    		result += "e";
    		break;
    	case 5:
    		result += "f";
    		break;
    	case 6:
    		result += "g";
    		break;
        case 7:
        	result += "h";
			break;
    	}
    	
    	result += (8 - this.arrivo.getY());
    	
    	if(this.catturato != null) result += "x" + this.getCatturato().getCod();
    	
    	return result;
    }
}
