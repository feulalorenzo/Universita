package domain;

public class Casella {

	private int x;
	private int y;
	
	
	public Casella() {}
	
	
	
	public Casella(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public int getX() {
		return this.x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return this.y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	public boolean isValid() {
		if(this.x <= 7 && this.x >= 0 && this.y <= 7 && this.y >= 0) return true;
		return false;
	}
	@Override
	public boolean equals(Object o) {
		if(!(o instanceof Casella)) return false;
		Casella c = (Casella)o;
		if(this.x == c.x && this.y == c.y) return true;
		return false;
	}
	
	
	
}
