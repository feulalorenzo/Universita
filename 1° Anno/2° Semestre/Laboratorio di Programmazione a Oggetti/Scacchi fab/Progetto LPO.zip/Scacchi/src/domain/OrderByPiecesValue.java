package domain;

import java.util.Comparator;

public class OrderByPiecesValue implements Comparator<Partita> {

	@Override
	public int compare(Partita p1, Partita p2) {
		if(p1.getScacchiera().getValueTable() > p2.getScacchiera().getValueTable()) return 1;
		else if(p1.getScacchiera().getValueTable() < p2.getScacchiera().getValueTable()) return  -1;
		return 0;
	}

}
