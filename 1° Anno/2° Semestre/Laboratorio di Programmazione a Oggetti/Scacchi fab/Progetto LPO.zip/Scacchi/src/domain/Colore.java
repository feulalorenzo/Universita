package domain;

public enum Colore {

	
	BIANCO, NERO
}
