package domain;

public class Utente extends Giocatore{

	private String username;
	private String password;
	private Colore colore;
	

	
	
	@Override
	public boolean equals(Object o) {
		if(!(o instanceof Utente)) return false;
		
		Utente u = (Utente)o;
		
		if(this.username.equals(u.username)) return true;
		return false;
	}
	
	
}
