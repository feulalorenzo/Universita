package domain;

public enum Esito {

	TERMINATA, SOSPESA, PATTA
}
