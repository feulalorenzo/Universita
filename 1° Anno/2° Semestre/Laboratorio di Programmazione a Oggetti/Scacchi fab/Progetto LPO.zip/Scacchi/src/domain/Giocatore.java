package domain;

public class Giocatore {

	private String username;
	private String password;
	private Colore colore;
	
	
	
	public String getUsername() {
		return this.username;
	}
	public void setUsername(String u) {
		this.username = u;
	}
	
	
	public String getPassword() {
		return this.password;
	}
	public void setPassword(String p) {
		this.password =p;
	}
	public Colore getColore() {
		return this.colore;
	}
	public void setColore(Colore c) {
		this.colore = c;
	}
	
}
