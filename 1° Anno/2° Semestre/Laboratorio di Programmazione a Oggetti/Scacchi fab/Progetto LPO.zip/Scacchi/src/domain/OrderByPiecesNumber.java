package domain;

import java.util.Comparator;

public class OrderByPiecesNumber implements Comparator<Partita> {

	@Override
	public int compare(Partita p1, Partita p2) {
		if(p1.getScacchiera().getNumberPieces() > p2.getScacchiera().getNumberPieces()) return 1;
		else if(p1.getScacchiera().getNumberPieces() < p2.getScacchiera().getNumberPieces()) return -1;
		return 0;
	}

}
