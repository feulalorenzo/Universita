package domain;

import java.util.ArrayList;

public class Partita implements Comparable<Partita>{

	private int id;
	private Giocatore g1;
	private Giocatore g2;
	private Scacchiera scacchiera;
	private Colore turno;
	private ArrayList<Mossa> listaMosse;
	private Esito esito;
	private Giocatore vincitore;
	private int contatorePareggio;
	
	public Partita() {
		this.turno = Colore.BIANCO;
		this.listaMosse = new ArrayList<>();
		this.contatorePareggio = 0;
		this.esito = null;
	}
	
	
	public int getId() {
		return this.id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public Giocatore getG1() {
		return this.g1;
	}
	public void setG1(Giocatore g1) {
		this.g1 = g1;
	}
	
	
	public Giocatore getG2() {
		return this.g2;
	}
	public void setG2(Giocatore g2) {
		this.g2 = g2;
	}
	
	public Scacchiera getScacchiera() {
		return this.scacchiera;
	}
	public void setScacchiera(Scacchiera s) {
		this.scacchiera = s;
	}
	

	public Colore getTurno() {
		return this.turno;
	}
	public void setTurno(Colore colore) {
		this.turno = colore;
	}
	
	public ArrayList<Mossa> getListaMosse(){
		return this.listaMosse;
	}
	public void setListaMosse(ArrayList<Mossa> l) {
		this.listaMosse = l;
	}
	
	public Esito getEsito() {
		return this.esito;
	}
	public void setEsito(Esito e) {
		this.esito = e;
	}

	public Giocatore getVincitore() {
		return this.vincitore;
	}
	public void setVincitore(Giocatore g) {
		this.vincitore = g;
	}
    
	
	public int getContatorePareggio() {
		return this.contatorePareggio;
	}
	public void setContatorePareggio(int contatorePareggio) {
		this.contatorePareggio = contatorePareggio;
	}
	

	public Giocatore getWhitePlayer() {

    	return g1.getColore() == Colore.BIANCO ? g1 : g2;
    }
    public Giocatore getBlackPlayer() {

    	return g1.getColore() == Colore.NERO ? g1 : g2;
    }
	
	
	public int getNumeroMosse() {
		return this.listaMosse.size();
	}
	
	
	
	
	public void updateTurno() {
		this.turno = this.turno == Colore.BIANCO ? Colore.NERO :Colore.BIANCO;
	}
	
	public void addMossaToListaMosse(Mossa mossa) {
		this.listaMosse.add(mossa);
	}
	
	public Giocatore getGiocatoreDiTurno() {
		
		return this.turno == this.g1.getColore() ? g1 : g2;
	}

	public Mossa undoLastMove() {
		
		int size = this.listaMosse.size();
		if(size > 0) {
		
			updateTurno();
			return this.listaMosse.remove(size - 1);
		}
		return null;
		
	}
	
	@Override
	public int compareTo(Partita p) {
		//ORDINE ID
		if(this.id > p.id) return 1;
		else if(this.id < p.id) return -1;		
		return 0;
	}
	
	
	public void updateContatorePareggio(Mossa mossa) {
		Pezzo pezzoCatturato = mossa.getCatturato();
		Pezzo pezzoMosso = mossa.getPezzo();
		if(pezzoCatturato == null && pezzoMosso.getTipo() != TipoPezzo.PEDONE) {
			contatorePareggio++;
		}
		else {
			contatorePareggio = 0;
		}
	}

    public boolean isStallo() {
    	if(contatorePareggio < 50) return false;
    	return true;
    }

    public boolean isTerminated() {
    	if(esito == Esito.TERMINATA) return true;
    	if(esito == Esito.PATTA) return true;
    	return false;
    }

    
	public boolean effettuaMossa(Mossa mossa) {
		
		// CONTROLLA SE LA MOSSA SIA CORRETTA
		if(!scacchiera.isValidMove(mossa, turno) ||
		   !scacchiera.isValidMovement(mossa, turno) ||
		   !scacchiera.isFreeWay(mossa)) return false;
		
		//CONTROLLA CHE IL RE DELLA MOSSA NON VADA IN SCACCO
		if(scacchiera.isScaccoAfterMove(mossa, turno)) return false;
		
		
		//REGISTRA NELLA MOSSA UN EVENTUALE PEZZO CATTURATO
		mossa.setCatturato(scacchiera);
		
		//MUOVE I PEZZI ALL'INTERNO DELLA SCACCHIERA
		scacchiera.moveTo(mossa.getPartenza(), mossa.getArrivo());
		
		//AGGIORNA LA LISTA DELLE MOSSE
		listaMosse.add(mossa);
		
		//AGGIORNA IL CONTATORE PER IL PAREGGIO
		updateContatorePareggio(mossa);
		
		//AGGIORNA IL TURNO
		updateTurno();
		
		//VERIFICA SE LA PARTITA è TERMINATA (SCACCO MATTO O STALLO)
		if(scacchiera.isScaccoMatto(turno)) {
			esito = Esito.TERMINATA;
			vincitore = turno == Colore.BIANCO ? getBlackPlayer() : getWhitePlayer();
			System.out.println("Scacco matto");
			
		}
		else if(isStallo()) {
			esito = Esito.PATTA;
		}
		
		return true;
	}
}
