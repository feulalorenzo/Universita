package domain;

public enum TipoPezzo {
	RE, REGINA, ALFIERE, TORRE, CAVALLO, PEDONE
}
