package domain;

public interface DataInitializable<T> {

	
	
	 default void initializeData (T param) {};
}
