package domain;

public class Scacchiera {

	private Pezzo[][] scacchiera = new Pezzo[8][8];

	
	public Scacchiera(){
		
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
			    Pezzo pezzo = null;
				if(i == 0) {
					pezzo = new Pezzo();
					pezzo.setColore(Colore.NERO);
					if(j == 0 || j == 7) pezzo.setTipo(TipoPezzo.TORRE);
					if(j == 1 || j == 6) pezzo.setTipo(TipoPezzo.CAVALLO);
					if(j == 2 || j == 5) pezzo.setTipo(TipoPezzo.ALFIERE);
					if(j == 3) pezzo.setTipo(TipoPezzo.REGINA);
					if(j == 4) pezzo.setTipo(TipoPezzo.RE);
					
				}
				if(i == 7) {
					pezzo = new Pezzo();
					pezzo.setColore(Colore.BIANCO);
					if(j == 0 || j == 7) pezzo.setTipo(TipoPezzo.TORRE);
					if(j == 1 || j == 6) pezzo.setTipo(TipoPezzo.CAVALLO);
					if(j == 2 || j == 5) pezzo.setTipo(TipoPezzo.ALFIERE);
					if(j == 3) pezzo.setTipo(TipoPezzo.REGINA);
					if(j == 4) pezzo.setTipo(TipoPezzo.RE);
					
				}
				
				if(i == 1) {
					pezzo = new Pezzo();
					pezzo.setColore(Colore.NERO);
					pezzo.setTipo(TipoPezzo.PEDONE);
					
				}
				if(i == 6) {
					pezzo = new Pezzo();
					pezzo.setColore(Colore.BIANCO);
					pezzo.setTipo(TipoPezzo.PEDONE);
					
				}
				
				scacchiera[i][j] = pezzo;
				if(pezzo != null) {
				}
				else {
				}
				
			}
		}
		
		
		
	}
	
	public Pezzo[][] getScacchiera(){
		return this.scacchiera;
	}
	
	public void setScacchiera(Pezzo[][] s) {
		this.scacchiera = s;
	}
	
	public Pezzo getPezzo(Casella c) {
	    return this.scacchiera[c.getX()][c.getY()];
	}
	
	public void setPezzo(Casella c, Pezzo p) {
		this.scacchiera[c.getX()][c.getY()] = p;
	}
	
	public void copy(Scacchiera s) {
		
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				this.scacchiera[i][j] = s.scacchiera[i][j];
			}
		}
	}
	
	public void moveTo(Casella from, Casella to) {
		Pezzo p = scacchiera[from.getX()][from.getY()];
		scacchiera[from.getX()][from.getY()] = null;
		scacchiera[to.getX()][to.getY()] = p;
		
	}
	
	public void undo(Mossa mossa) {
		Casella partenza = mossa.getPartenza();
		Casella arrivo = mossa.getArrivo();
		
		this.scacchiera[partenza.getX()][partenza.getY()] = this.scacchiera[arrivo.getX()][arrivo.getY()];
		if(mossa.hasCaptured()) {
			this.scacchiera[arrivo.getX()][arrivo.getY()] = mossa.getCatturato(); 
		}
		else {
			this.scacchiera[arrivo.getX()][arrivo.getY()] = null;
		}
	}
	
	public int getValueTable() {
		int result = 0;
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				if(scacchiera[i][j] != null) {
					result = scacchiera[i][j].getValore();
				}
			}
		}
		return result;
	}
	
	public int getNumberPieces() {
		int result = 0;
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				if(scacchiera[i][j] != null) {
					result += 1;
				}
			}
		}
		return result;
	}
		
	public Casella getKingPosition(Colore colore) {
		Casella casella = null;
		for(int i = 0; i < 8 && casella == null; i++) {
			for(int j = 0; j < 8 && casella == null; j++) {
				Casella c = new Casella(i,j);
				if(this.getPezzo(c) != null && this.getPezzo(c).getTipo() == TipoPezzo.RE && this.getPezzo(c).getColore() == colore) {
					casella = c;
				}
			}
		}
		return casella;
	}

	public boolean isFreeWay(Mossa mossa) {
	    Casella partenza = mossa.getPartenza();
	    Casella arrivo = mossa.getArrivo();
	    TipoPezzo tipoPezzo = this.getPezzo(partenza).getTipo();

	    if (tipoPezzo == TipoPezzo.ALFIERE || tipoPezzo == TipoPezzo.REGINA) {
	        int deltaX = Math.abs(arrivo.getX() - partenza.getX());
	        int deltaY = Math.abs(arrivo.getY() - partenza.getY());

	        if (deltaX == deltaY) {
	            // MOVIMENTO IN DIAGONALE
	            int deltaXSign = Integer.compare(arrivo.getX(), partenza.getX());
	            int deltaYSign = Integer.compare(arrivo.getY(), partenza.getY());

	            int x = partenza.getX() + deltaXSign;
	            int y = partenza.getY() + deltaYSign;

	            // CONTROLLA SE CI SONO PEZZI NEL MEZZO DEL CAMMINO DELL'ALFIERE O DELLA REGINA
	            while (x != arrivo.getX() && y != arrivo.getY()) {
	                if (this.getPezzo(new Casella(x, y)) != null) {
	                    return false; // CI SONO PEZZI NEL MEZZO
	                }
	                x += deltaXSign;
	                y += deltaYSign;
	            }
	        }
	    }

	    if (tipoPezzo == TipoPezzo.TORRE || tipoPezzo == TipoPezzo.REGINA) {
	        int deltaX = Math.abs(arrivo.getX() - partenza.getX());
	        int deltaY = Math.abs(arrivo.getY() - partenza.getY());

	        if (deltaX > 0 && deltaY == 0) {
	            // MOVIMENTO IN ORIZZONTALE (COME UNA TORRE O REGINA)
	            int minX = Math.min(partenza.getX(), arrivo.getX()) + 1;
	            int maxX = Math.max(partenza.getX(), arrivo.getX());
	            int y = partenza.getY();

	            for (int i = minX; i < maxX; i++) {
	                if (this.getPezzo(new Casella(i, y)) != null) {
	                    return false; // CI SONO PEZZI NEL MEZZO
	                }
	            }
	        } else if (deltaX == 0 && deltaY > 0) {
	            // MOVIMENTO IN VERTICALE (COME UNA TORRE O REGINA)
	            int minY = Math.min(partenza.getY(), arrivo.getY()) + 1;
	            int maxY = Math.max(partenza.getY(), arrivo.getY());
	            int x = partenza.getX();

	            for (int i = minY; i < maxY; i++) {
	                if (this.getPezzo(new Casella(x, i)) != null) {
	                    return false; // CI SONO PEZZI NEL MEZZO
	                }
	            }
	        }
	    }

	    return true;
	}

	public boolean isValidMovement(Mossa mossa, Colore colore) {
	    
		int deltaX = Math.abs(mossa.getArrivo().getX() - mossa.getPartenza().getX());
	    int deltaY = Math.abs(mossa.getArrivo().getY() - mossa.getPartenza().getY());
	    
	    TipoPezzo tipoPezzo = this.getPezzo(mossa.getPartenza()).getTipo();
	    
	    
	    if (tipoPezzo == TipoPezzo.ALFIERE || tipoPezzo == TipoPezzo.REGINA) {
	        if (deltaX == deltaY) return true;
	    }
	    
	    

	    if (tipoPezzo == TipoPezzo.TORRE || tipoPezzo == TipoPezzo.REGINA) {
	        if ((deltaX == 0 && deltaY > 0) || (deltaX > 0 && deltaY == 0)) return true;
	    }
	    
	    

	    if (tipoPezzo == TipoPezzo.RE) {
	        if (deltaX <= 1 && deltaY <= 1) return true;
	    }
	    
	    

	    if (tipoPezzo == TipoPezzo.CAVALLO) {
	        if ((deltaX == 2 && deltaY == 1) || (deltaX == 1 && deltaY == 2)) return true;
	    }
	    
	    

	    if (tipoPezzo == TipoPezzo.PEDONE) {
	        int direzione = (colore == Colore.BIANCO ? 1 : -1);
	        int differenza = mossa.getArrivo().getX() - mossa.getPartenza().getX();
	        Pezzo pezzoArrivo = this.getPezzo(mossa.getArrivo());

	        // CONTROLLA CHE IL PEDONE NON SI MUOVA ALL'INDIETRO
	        if ((direzione == 1 && differenza > 0) || (direzione == -1 && differenza < 0)) return false;

	        // CONTROLLA CHE IL PEDONE POSSA MUOVERSI IN AVANTI
	        if (deltaX == 1 && deltaY == 0 && pezzoArrivo == null) return true;

	        // CONTROLLA CHE IL PEDONE POSSA MUOVERSI IN AVANTI DI 2 AL PRIMO TURNO (DA CONTROLLARE)
	        if ((deltaX == 2 && deltaY == 0) && mossa.getPartenza().getX() == (colore == Colore.BIANCO ? 6 : 1)) return true;

	        // CONTROLLA CHE IL PEDONE POSSA MANGIARE IN DIAGONALE
	        if ((deltaX == 1 && deltaY == 1) && pezzoArrivo != null && pezzoArrivo.getColore() != colore) return true;
	    }
	    
	    return false;
	}

	public boolean isValidMove(Mossa mossa, Colore colore) {
		
	    Casella partenza      = mossa.getPartenza();
	    Casella arrivo        = mossa.getArrivo();
	    Pezzo   pezzoPartenza = mossa.getPezzo();
	    Pezzo   pezzoArrivo   = mossa.getCatturato();

	    // CONTROLLA SE LA CASELLA DI ARRIVO E DI PARTENZA SIANO VALIDE
	   
	    if (!(partenza.isValid() && arrivo.isValid())) return false;

	    
	    // CONTROLLA CHE NON COINCIDANO
	    
	    if (partenza.equals(arrivo)) return false;
	    

	    // CONTROLLA CHE CI SIA UN PEZZO NELLA CASELLA DI PARTENZA
	    if (pezzoPartenza == null) return false;
	    

	    // CONTROLLA CHE NON CI SIA UN PEZZO DELLO STESSO COLORE NELLA CASELLA ARRIVO
	    if (pezzoArrivo != null && pezzoPartenza.getColore() == pezzoArrivo.getColore()) return false;

	    // CONTROLLA CHE IL PEZZO CHE SI STIA SPOSTANDO SIA DEL GIOCATORE DI TURNO
	    if (pezzoPartenza.getColore() != colore) return false;
	 
	    return true;
	}

	public boolean isScacco(Colore colore) {
	    Casella posizioneRe = this.getKingPosition(colore);

	    for (int i = 0; i < 8; i++) {
	        for (int j = 0; j < 8; j++) {
	            Casella casella = new Casella(i, j);
	            Pezzo pezzo = this.getPezzo(casella);

	            if (pezzo != null && pezzo.getColore() != colore) {
	                Mossa mossa = new Mossa();
	                mossa.setPartenza(casella);
	                mossa.setArrivo(posizioneRe);
	                mossa.setPezzo(pezzo);

	                if (isValidMovement(mossa, colore == Colore.BIANCO ? Colore.NERO : Colore.BIANCO) && isFreeWay(mossa)) {
	                    return true;
	                }
	            }
	        }
	    }

	    return false;
	}

	public boolean isScaccoMatto(Colore colore) {
	    if (canKingMove(colore) || canPieceDefendKing(colore)) {
	        return false;
	    }
	    return true;
	}

	public boolean isScaccoAfterMove(Mossa mossa, Colore colore) {
	    Scacchiera s = new Scacchiera();
	    s.copy(this);
	    s.moveTo(mossa.getPartenza(), mossa.getArrivo());
	    return s.isScacco(colore);
	}

	public boolean canKingMove(Colore colore) {
	    Casella posizioneRe = this.getKingPosition(colore);

	    for (int i = -1; i <= 1; i++) {
	        for (int j = -1; j <= 1; j++) {
	            Casella casella = new Casella(posizioneRe.getX() + i, posizioneRe.getY() + j);

	            if (casella.isValid()) {
	                Mossa mossa = new Mossa();
	                mossa.setPartenza(posizioneRe);
	                mossa.setArrivo(casella);
	                mossa.setPezzo(this.getPezzo(posizioneRe));

	                if (isValidMove(mossa, colore) && isValidMovement(mossa, colore) && isFreeWay(mossa)) {
	                    if (!isScaccoAfterMove(mossa, colore)) {
	                        return true;
	                    }
	                }
	            }
	        }
	    }
	    return false;
	}

	public boolean canPieceDefendKing(Colore colore) {
	    Casella posizioneRe = this.getKingPosition(colore);

	    for (int i = 0; i < 8; i++) {
	        for (int j = 0; j < 8; j++) {
	            Casella partenza = new Casella(i, j);
	            Pezzo pezzo = this.getPezzo(partenza);

	            if (pezzo != null && pezzo.getColore() == colore) {
	                for (int x = 0; x < 8; x++) {
	                    for (int y = 0; y < 8; y++) {
	                        Casella arrivo = new Casella(x, y);
	                        Mossa mossa = new Mossa();
	                        mossa.setPartenza(partenza);
	                        mossa.setArrivo(arrivo);
	                        mossa.setPezzo(pezzo);

	                        if (isValidMove(mossa, colore) && isValidMovement(mossa, colore) && isFreeWay(mossa)) {
	                            if (!isScaccoAfterMove(mossa, colore)) {
	                                return true;
	                            }
	                        }
	                    }
	                }
	            }
	        }
	    }
	    return false;
	}


}
