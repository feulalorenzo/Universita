package domain;

import java.util.Random;

public class Computer extends Giocatore {
	
	private static Computer istance = new Computer();
	private String username;
	private String password;
	private Colore colore;
	
	private Computer(){}
	
	
	public static Computer getIstance() {
		return istance;
	}

	
	public String getUsername() {
		return "Computer";
	}
	
	public String getPassword() {
		return "Computer";
	}
	
	public Mossa generateValidMove(Scacchiera scacchiera) {
		
		Mossa mossa = new Mossa();
		
		do {
		Casella partenza = generateValidStartPosition(scacchiera);
		Casella arrivo = generateDestination();
		Pezzo pezzo = scacchiera.getPezzo(partenza);
		
		mossa.setPartenza(partenza);
		mossa.setArrivo(arrivo);
		mossa.setPezzo(pezzo);
		}
		while(!(isValidComputerMove(scacchiera, mossa)));
		return mossa;
	}
	
	private Casella generateValidStartPosition(Scacchiera scacchiera) {
		
		Casella casella;
		Pezzo pezzo;
		
		do {
			
			int i = new Random().nextInt(8);
			int j = new Random().nextInt(8);
			casella = new Casella(i,j);
			pezzo = scacchiera.getPezzo(casella);
		}
		while(pezzo == null || pezzo.getColore() != colore);
		
		return casella;
	}	
	
 	
	private Casella generateDestination() {
		
		int i = new Random().nextInt(8);
		int j = new Random().nextInt(8);
		
		Casella casella = new Casella(i,j);
		
		return casella;
	}

	private boolean isValidComputerMove(Scacchiera scacchiera, Mossa mossa) {
		
		// VERIFICA CHE LA MOSSA SIA CORRETTA
	    if (!scacchiera.isValidMove(mossa, colore) ||
	        !scacchiera.isValidMovement(mossa, colore) ||
	        !scacchiera.isFreeWay(mossa)) {
	        return false;
	    }

	    // VERIFICA SE LA MOSSA METTE IL RE IN SCACCO
	    if(scacchiera.isScaccoAfterMove(mossa, colore)) return false;
	    return true;
	}
	
}
