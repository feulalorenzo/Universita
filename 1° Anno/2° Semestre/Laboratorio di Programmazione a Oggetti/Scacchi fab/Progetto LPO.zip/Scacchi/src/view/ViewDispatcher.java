package view;

import java.io.IOException;

import domain.Partita;
import domain.Utente;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class ViewDispatcher {

	private static ViewDispatcher istance = new ViewDispatcher();
	private final String PATH = "/viste/";
	private final String SUFFIX = ".fxml";
	private Stage stage;
	private BorderPane layout;
	private ViewDispatcher() {}
	
	
	
	public static ViewDispatcher getIstance() {
		return istance;
	}
	
	
	public void login(Stage stage) throws IOException{
		View view = loadView("login");
		this.stage = stage;
		Scene scene = new Scene(view.getView());
		stage.setScene(scene);
		
	}
	
	
	public void login() throws IOException {
		View view = loadView("login");
		Scene scene = new Scene(view.getView());
		stage.setScene(scene);
	}
	
	public void passwordDimenticata(String nome, Utente utente) throws IOException{
		View view = loadView(nome);
		Scene scene = new Scene(view.getView());
		view.getController().initializeData(utente);
		stage.setScene(scene);
		
	}
	
	public void iscrivi(String nome, Utente utente) throws IOException{
		View view = loadView(nome);
		Scene scene = new Scene(view.getView());
		view.getController().initializeData(utente);
		stage.setScene(scene);
	}
	
	public void home(String nome, Utente utente) throws IOException{
		View view = loadView(nome);
		
		this.layout = (BorderPane)view.getView();
		Scene scene = new Scene(view.getView());
		view.getController().initializeData(utente);
		stage.setScene(scene);
		
		
		
	}
	
	public <T> void switchGeneralView(String nome, T param) throws IOException{
		View<T> view = loadView(nome);
		Scene scene = new Scene(view.getView());
		view.getController().initializeData(param);
		stage.setScene(scene);
	}
	
	
    public <T> void switchView(String nome, T param) throws IOException {
    	View view = loadView(nome);
		layout.setCenter(view.getView());
		view.getController().initializeData(param);
		
	}
    
	public View loadView(String nome) throws IOException {
		View view = new View();
		FXMLLoader loader = new FXMLLoader(getClass().getResource(PATH + nome + SUFFIX));
		view.setView((Parent)loader.load());
		view.setController(loader.getController());
		return view;
	}

	


	
	
	
}
