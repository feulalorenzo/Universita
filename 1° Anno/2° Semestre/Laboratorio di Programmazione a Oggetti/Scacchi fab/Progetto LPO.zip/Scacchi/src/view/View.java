package view;

import domain.DataInitializable;
import javafx.fxml.Initializable;
import javafx.scene.Parent;

public class View<T> {

	private Parent view;
	private DataInitializable<T> controller;
	
	
	public Parent getView() {
		return this.view;
	}
	public void setView(Parent p) {
		this.view = p;
	}
	public DataInitializable<T> getController(){
		return this.controller;
	}
	public void setController(DataInitializable<T> c) {
		this.controller = c;
	}
}
