/*
	LPS Example

	Function Pointers Parameter

	Language: C99
 	Style: plain C
 	Version: Ref-pc
 */

/*
	This example introduces the use of a function pointer as a parameter of a function
*/

#include <stdio.h>

/* 
	Functions with return type int and an int parameter
*/
int f1( int x ) {
	return x * x - 5 * 5 + 2;
}

int f2( int x ) {
	return 2 * x - 666;
}

int f3( int x ) {
	return x * x * x / 4 - 37 * x;
}

int f0( int x )
{
	return x * x;
}

/*
	Definition of the function that calculates the sum of squares of the values
    assumed by another function (passed as a parameter) in a range
    of values, whose extremes are also specified as parameters
*/
int somma_quadrati( int i1, int i2, int f(int) ) {
	int ris = 0, t;

	for ( ; i1 <= i2 ; i1++ ) {
		t = f( i1 );
		ris += t * t;
	}
	return ris;
}

/*
	In the main function, the function somma_quadrati is called, several times.
	In each call, a different function (having return type int and an int parameter)
	is passed as third parameter.
	Notice that the argument of the function pointer parameter can be the name of a function
	or a pointer to a function. The effect is exaclty the same.
*/
int main( void )
{
	int s, a, b;
	printf("\nImmettere l'estremo inferiore dell'intervallo di valori:\n");
	scanf("%d", &a);
	printf("\nImmettere l'estremo superiore dell'intervallo di valori:\n");
	scanf("%d", &b);
	
	/*
		Calls somma_quadrati with f1 as third parameter.
		The third parameter, in this call, is a pointer to the function f1.
	*/
	s = somma_quadrati( a, b, &f1 );
	printf("\nRisultato di somma_quadrati applicato a f1: %d\n", s );

	/*
		Calls somma_quadrati with f3 as third parameter.
		The third parameter, in this call, is the name of the function f1.
	*/
	s = somma_quadrati( a, b, f3 );
	printf("\nRisultato di somma_quadrati applicato a f1: %d\n", s );

	return 0;
}
