/*
	LPS Example

	Function Pointers Array

	Language: C99
 	Style: plain C
 	Version: Ref-pc
 */

/*
	This example introduces the use of an array of function pointers
*/

#include <stdio.h>
#include <stdlib.h>

/* 
	Functions with return type int and an int parameter
*/
int f1( int x ) {
	return x * x - 5 * 5 + 2;
}

int f2( int x ) {
	return 2 * x - 666;
}

int f3( int x ) {
	return x * x * x / 4 - 37 * x;
}

int f4( int x ) {
	return x * x / 9 - 12 * x;
}

int f5( int x ) {
	return 5 * x * x / 4 - 7777;
}

int f6( int x ) {
	return 100000 - 7 * x / 6;
}

/* 
	Declaration of a variable that has type
	pointer to a function having return type int and an int parameter
*/
int ( * puntatore_funzione )( int ) ;

/* 
	Declaration of an array of 6 elements that have type
	pointer to a function having return type int and an int parameter.
	Notice that array elements can be intialized either by a function name 
	(as for the first three elements) or by a pointer to a function
	(as for the last three elements): the effect is exactly the same. 
*/
int ( * elenco_funzioni[ 6 ] )( int ) = { f1, f2, f3, &f4, &f5, &f6 };

int main( void )
{
	int s = 0, a, b, x;
	printf("\nImmettere l'estremo inferiore dell'intervallo di valori:\n");
	scanf("%d", &a);
	printf("\nImmettere l'estremo superiore dell'intervallo di valori:\n");
	scanf("%d", &b);
	printf("\nImmettere un valore da 1 a 6 per selezionare la funzione da usare:\n\n");
	scanf("%d", &x);

	if ( x < 1 || x > 6 ) {
		printf("Errore, selezionata una funzione inesistente!\n");
		exit(1);
	}

	/*
		the variable puntatore_funzione assumes the value of one of the array elements
	*/
	puntatore_funzione = elenco_funzioni[ x - 1 ];
	
	/* 
		calculates the sum of the values of a function that has a parameter
		int and an int result, for all parameter values between a and b
		the function referenced through a pointer
	*/
	for ( int i = a ; i < b ; i++ )
		s += puntatore_funzione( i );

	printf( "%d\n", s );

	return 0;
}
