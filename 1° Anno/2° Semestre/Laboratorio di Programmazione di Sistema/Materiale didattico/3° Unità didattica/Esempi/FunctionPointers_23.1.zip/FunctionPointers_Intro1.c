/*
	LPS Example

	Function Pointers Intro

	Language: C99
 	Style: plain C
 	Version: Ref-pc
 */

/*
	Reference Plain C Solution 1
	This solution does not use the function pointer concept.
*/

/* 
	Il programma chiede all'utente di scegliere 2 funzioni
	(tra 4 possibilità) e di inserire gli estremi di un
	intervallo di valori.
	Il programma conta quanti sono i punti appartenenti
	all'intervallo in cui la prima funzione scelta è maggiore
	della seconda.
*/
#include <stdio.h>

/* 
	Functions with return type int and an int parameter
*/
int f1( int x ) {
	return x * x - 5 * 5 + 2;
}

int f2( int x ) {
	return 2 * x - 666;
}

int f3( int x ) {
	return x * x * x / 4 - 37 * x;
}

int f0( int x )
{
	return x * x;
}

int scelta1, scelta2, contatore = 0;

int main( void )
{
	int a, b;
	printf("\nImmettere l'estremo inferiore dell'intervallo di valori:\n");
	scanf("%d", &a);
	printf("\nImmettere l'estremo superiore dell'intervallo di valori:\n");
	scanf("%d", &b);
	printf("\nImmettere 0, 1, 2, o 3 per selezionare la prima funzione da usare:\n\n");
	scanf("%d", &scelta1);
	printf("\nImmettere 0, 1, 2, o 3 per selezionare la seconda funzione da usare:\n\n");
	scanf("%d", &scelta2);
	if ( scelta1 == scelta2 ) {
		printf("Devono essere selezionate due diverse funzioni!\n");
		return 0;
	}
		
	/* 
		Conta quanti sono i punti appartenenti all'intervallo
		in cui la prima funzione scelta è maggiore della seconda
	*/
	for ( int i = a ; i < b ; i++ ) {
		int v1, v2;

		// calcola valore della prima funzione per punto i
		switch ( scelta1 ) {
			case 0: v1 = f0( i ); break;
			case 1: v1 = f1( i ); break;
			case 2: v1 = f2( i ); break;
			case 3: v1 = f3( i ); break;
			default:
				printf( "Errore! Funzione sconosciuta!\n" );
				return 0;
		}

		// calcola valore della seconda funzione per punto i
		switch ( scelta2 ) {
			case 0: v2 = f0( i ); break;
			case 1: v2 = f1( i ); break;
			case 2: v2 = f2( i ); break;
			case 3: v2 = f3( i ); break;
			default:
				printf( "Errore! Funzione sconosciuta!\n" );
				return 0;
		}

		if ( v1 > v2 ) contatore++;
	}

	printf( "%d\n", contatore );

	return 0;
}
