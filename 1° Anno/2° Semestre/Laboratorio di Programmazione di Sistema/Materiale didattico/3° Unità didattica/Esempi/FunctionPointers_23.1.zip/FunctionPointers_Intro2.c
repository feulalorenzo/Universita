/*
	LPS Example

	Function Pointers Intro

	Language: C99
 	Style: plain C
 	Version: Ref-pc
 */

/*
	Reference Plain C Solution 2
	This solution introduces the function pointer concept.
*/

/* 
	Il programma chiede all'utente di scegliere 2 funzioni
	(tra 4 possibilità) e di inserire gli estremi di un
	intervallo di valori.
	Il programma conta quanti sono i punti appartenenti
	all'intervallo in cui la prima funzione scelta è maggiore
	della seconda.
*/
#include <stdio.h>

/* 
	Functions with return type int and an int parameter
*/
int f1( int x ) {
	return x * x - 5 * 5 + 2;
}

int f2( int x ) {
	return 2 * x - 666;
}

int f3( int x ) {
	return x * x * x / 4 - 37 * x;
}

int f0( int x )
{
	return x * x;
}

/* 
	Declaration of a variable that has type
	pointer to a function having return type int and an int parameter

	Aspetto tecnico: le parentesi tonde attorno "* scelta1" sono necessarie.
	Se non ci fossero, la dichiarazione sarebbe:
	int *scelta1( int );
	In tale dichiarazione, il nome scelta1 è preceduto da * (che suggerisce
	che scelta1 sia un puntatore) ma è seguito da ( ) (che suggerisce
	che scelta 1 sia una funzione). Poiché in C l'operatore
	postfisso ha sempre la precedenza su quello prefisso, la
	dichiarazione verrebbe interpretata come dichiarazione di
	una funzione che restituisce come risultato un puntatore a int.
*/
int ( * scelta1 )( int ), ( * scelta2 )( int ), contatore = 0;

int main( void )
{
	int a, b, x;
	printf("\nImmettere l'estremo inferiore dell'intervallo di valori:\n");
	scanf("%d", &a);
	printf("\nImmettere l'estremo superiore dell'intervallo di valori:\n");
	scanf("%d", &b);
	
	/* 
		Assegnamento ad una variabile puntatore a funzione
		di un valore di tipo puntatore a funzione. 
		Aspetto tecnico: ci sono due modi del tutto equivalenti
		di assegnare un valore di tipo puntatore a funzione ad
		una variabile puntatore a funzione.
		1) Si ottiene un puntatore ad una certa funzione, 
		applicando l'operatore & al nome della funzione
		come mostrato nell'assegnamento a scelta1.
		2) Si usa direttamente il nome della funzione come 
		operando destro dell'assegnamento, come mostrato
		nell'assegnamento a scelta2; in questo caso il nome
		della funzione viene implicitamente convertito in 
		puntatore ad essa, ed assegnato alla variabile puntatore.
	*/
	printf("\nImmettere 0, 1, 2, o 3 per selezionare la prima funzione da usare:\n\n");
	scanf("%d", &x);
	switch ( x ) {
		case 0: scelta1 = &f0; break;
		case 1: scelta1 = &f1; break;
		case 2: scelta1 = &f2; break;
		case 3: scelta1 = &f3; break;
		default:
			printf( "Errore! Funzione sconosciuta!\n" );
			return 0;
	}

	printf("\nImmettere 0, 1, 2, o 3 per selezionare la seconda funzione da usare:\n\n");
	scanf("%d", &x);
	switch ( x ) {
		case 0: scelta2 = f0; break;
		case 1: scelta2 = f1; break;
		case 2: scelta2 = f2; break;
		case 3: scelta2 = f3; break;
		default:
			printf( "Errore! Funzione sconosciuta!\n" );
			return 0;
	}

	/* 
		Conta quanti sono i punti appartenenti all'intervallo
		in cui la prima funzione scelta è maggiore della seconda.
		Le due funzioni sono chiamate attraverso puntatori.
		Aspetto tecnico: ci sono due modi del tutto equivalenti
		di chiamare attraverso un puntatore a funzione, la 
		funzione a cui esso si riferisce.
		1) Si applica l'operatore * che dato un puntatore a funzione
		restituisce la funzione, e al risultato dell'* si applica
		l'operatore di chiamata ( ). Questo caso è mostrato dalla
		chiamata attraverso scelta2.
		2) Si applica direttamente l'operatore di chiamata alla
		variabile puntatore a funzione. Questo caso è mostrato dalla
		chiamata attraverso scelta1.
	*/
	for ( int i = a ; i < b ; i++ ) {
		int v1, v2;
		// calcola valore della prima funzione per punto i
		v1 = scelta1( i );
		// calcola valore della seconda funzione per punto i
		v2 = (*scelta2)( i );

		if ( v1 > v2 ) contatore++;
	}

	printf( "%d\n", contatore );

	return 0;
}
