/*
	LPS Example

	Dynamic Memory Example 5

	Language: C89
 	Style: plain C
 	Version: LPS23
 */

/*
	This example shows the use of dynamic memory allocation to build dynamic arrays.
*/

#include <stdlib.h>
#include <stdio.h>

/*
	The four dynamic memory allocation/de-allocation functions
	of the C Standard Library
*/

/* Allocate uninitialized memory */
void *malloc( size_t );

/* Allocate initialized memory */
void *calloc( size_t , size_t ); 

/* Change the size of an allocated object */
void *realloc( void *, size_t );

/* De-allocate memory (allocated by the other 3 functions) */
void free ( void * );

struct T {
	int a;
	float b;
	double c;
} *p1, *p2, *pt;


int main( void ) {
	int i;

	/* alloca un array dinamico non inizializzato di 5 elementi */
	p1 = malloc( 5 * sizeof struct T );
	if ( p1 == 0 ) return 1;			/* esce in caso non ci sia memoria */
	for ( i = 0 ; i < 5 ; i++ ) p1[ i ] = 100 + i;

	/* alloca un array dinamico inizializzato (tutti i byte a valore 0)
		di 15 elementi */
	p2 = calloc( 15, sizeof struct T );
	if ( p2 == 0 ) return 1;			/* esce in caso non ci sia memoria */
	for ( i = 0 ; i < 15 ; i++ ) printf( "%d ", p2[ i ] );

	/* cambia a 105 la lunghezza dell'array puntato da p1 */
	pt = realloc( p1, 105 * sizeof struct T );
	if ( pt == 0 ) return 1;			/* esce in caso non ci sia memoria */
	p1 = pt;

	return 0;
}

