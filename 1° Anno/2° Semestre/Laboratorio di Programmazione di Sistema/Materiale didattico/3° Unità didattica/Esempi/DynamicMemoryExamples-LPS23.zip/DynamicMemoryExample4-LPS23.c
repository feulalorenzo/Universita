/*
	LPS Example

	Dynamic Memory Example 4

	Language: C89
 	Style: plain C
 	Version: LPS23
 */

/*
	This example shows a memory trash due to a dandling pointer.
	C Standard does not have garbage collection.
*/

#include <stdlib.h>
#include <stdio.h>
#define BLOCK_SIZE 1000

int main( void ) {

	int *p1, *p2, i;
	int h = 0;

    p2 = malloc( BLOCK_SIZE * sizeof (int) );
    for ( i = 0 ; i < BLOCK_SIZE ; i++ ) p2[ i ] = 2;
    /* it seems that I don't need this memory block anymore, let's free it */
	free( p2 ); /* after the call to free() p2 is not valid */

    p1 = malloc( BLOCK_SIZE * sizeof (int) );
    for ( i = 0 ; i < BLOCK_SIZE ; i++ ) p1[ i ] = 1;
    
    /* p2 is invalid, should not be dereferenced */
	p2[ 2 ] = 3;
    
    for ( i = 0 ; i < BLOCK_SIZE ; i++ ) 
        if ( p1[ i ] != 1 ) printf( "Un valore è stato alterato!\n");
    

	printf( "Fine Programma!\n" );
	return 0;
}
