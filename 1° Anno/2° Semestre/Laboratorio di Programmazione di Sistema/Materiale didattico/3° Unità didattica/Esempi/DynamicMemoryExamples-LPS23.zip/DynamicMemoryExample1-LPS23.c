/*
	LPS Example

	Dynamic Memory Example 1

	Language: C99
 	Style: plain C
 	Version: LPS23
 */

/*
	This example introduces the dynamic memory allocation idea and the malloc functions
*/

#include <stdlib.h>
#include <stdio.h>

/*
	Il parametro di malloc è la dimensione espressa in byte dell'oggetto che
	viene richiesto di allocare.
	size_t è un alias per uno dei tipi standard unsigned, scelto dall'implementazione
*/
void *malloc( size_t );

struct T {
	int a;
	float b;
	double c;
} v = { -1, 2.5f, -3.14 };

int main( void ) {

	struct T *new_object;

	new_object = malloc( sizeof (struct T) );
	if ( new_object != NULL ) {
		scanf( "%d%f%lf", &(new_object -> a), 
					&(new_object -> b), &(new_object -> c) );

		v.b += new_object -> b;
		new_object -> a -= v.a;
		new_object -> c += v.c - v.b;

		printf( "%d %f %f", (new_object -> a), 
					(new_object -> b), (new_object -> c) );
	}

	return 0;
}

