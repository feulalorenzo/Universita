/*
	LPS Example

	Dynamic Memory Example 2

	Language: C99
 	Style: plain C
 	Version: LPS23
 */

/*
	This example shows that the lifetime of objects allocated by the malloc function
	is not constrained to a block. 
	C Standard defines this kind of objects to have "allocated storage duration".
	A noticeable application is allowing to define constructor functions.
*/

#include <stdlib.h>
#include <stdio.h>

struct T {
	int a;
	float b;
	double c;
} v = { -1, 2.5f, -3.14 };

/* Prototipo per un costruttore di oggetti di tipo struct T */
struct T *build_T( int, float, double );

int main( void ) {

	struct T *p = &v;
	char c;

	printf( "1: p -> a vale %d\n", p -> a );

	printf( "inserire 'A' per allocare un oggetto, altrimenti un altro carattere: ");
	scanf( "%c", &c );
	if ( c == 'A' ) {

		struct T *t = malloc( sizeof (struct T) );
		if ( t != NULL ) {
			printf( "inserire un intero: ");
			scanf( "%d", &(t -> a) );
			t -> b = 0.5f;
			t -> c = 3.5;
			p = t;			// ora p punta l'oggetto allocato dinamicamente
		}
		// qui termina lo scope entro cui si trova l'allocazione dell'oggetto
	}

	// se l'allocazione dell'oggetto è avvenuta con successo, l'oggetto esiste ancora
	printf( "2: p -> a vale %d\n", p -> a );

	// costruisce un nuovo oggetto mediante un costruttore
	p = build_T( 1, 2.1, 3.2 );
	if ( p ) {
		printf( "3: p -> a vale %d\n", p -> a );
	}

	return 0;
}

/* Costruttore di oggetti di tipo struct T */
struct T *build_T( int i , float f , double d ) {
	struct T *t = malloc( sizeof (struct T) );
	if ( t ) {
		t -> a = i;
		t -> b = f;
		t -> c = d;
	}
	return t;
}

