/*
	LPS Example

	Dynamic Memory Example 3

	Language: C89
 	Style: plain C
 	Version: LPS23
 */

/*
	This example shows that the lifetime of objects with allocated storage
	duration does not end when there are no more references to them.
	C Standard does not have garbage collection.
	Memory must be de-allocated by the programmer, calling free().
*/

#include <stdlib.h>
#include <stdio.h>
#define BLOCK_SIZE 1000000000

int main( void ) {

	int *p, i;
	int h = 0;

	while ( h < 100000 ) {
		p = malloc( BLOCK_SIZE * sizeof (int) );
		h++;
		if ( !p ) {
			printf( "Memoria terminata!\nEsco dal ciclo!\n" );
			break;
		} else *p = h;
		/*
			Se il ciclo continua, alla prossima iterazione a p viene assegnato
			un riferimento ad un altro oggetto, quindi l'oggetto attualmente puntato
			non ha più riferimenti. Tuttavia non viene de-allocato automaticamente.
		*/
		/* free( p ); */
	}

	printf( "Iterazioni effettuate : %d\n", h );
	printf( "Fine Programma!\n" );
	return 0;
}
