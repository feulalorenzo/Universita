/*
	LPS Example

	Routine 3-LPS23

	Language: C99
 	Style: plain C
 	Version: Ref-pc
 */

/*
	Original Plain C Code
*/

/*
	Questo esempio mostra la traduzione in ASM di un programma C
	contenente funzioni non-foglia
*/

#include <stdio.h>

int v, w, r1, r2;

int media( int a, int b ) {
	return ( a + b ) / 2;
}

int f( int x, int y, int z, int w ) {
	int t = media( x, y );
 	return t - media( z, w );
}

int main( void ) {

	/* input */
	scanf( "%d%d", &v, &w );

	r1 = f( 10, v, w, -20 );
	r2 = f( v, w, 24, -40 );

	/* output */
	printf( "%d %d\n", r1, r2 );

	return 0;
}
