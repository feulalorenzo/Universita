/*
	LPS Example

	VLA Intro 2

	Language: C99
 	Style: plain C
 	Version: LPS23-pc
*/

/*
	Caratteristiche dei VLA
*/

#include <stdbool.h>
#include <stdio.h>

int w = 10;

// dichiarazione VLA esterno (dunque statico): constraint violation
//int vla_esterno_errore[ w ];

/*
	Questa funzione dimostra che non è possibile definire
	un VLA (locale) statico
*/
/* void vla_locale_statico_errore( void ) {

	// legge da standard input quanti valori devono essere registrati
	int n;
	printf( "Quanti dati inserire? " );
	scanf( "%d", &n );

	// dichiarazione VLA statico: constraint violation
	static int dati[ n ];

	for ( int i = 0 ; i < n ; i++ )
		scanf( "%d", &dati[ i ] );

}
 */

/*
	Questa funzione dimostra che non è possibile inizializzare un VLA
*/
/* void vla_inizializzato_errore( void ) {

	// legge da standard input quanti valori devono essere registrati
	int n;
	printf( "Quanti dati inserire? " );
	scanf( "%d", &n );

	// dichiarazione VLA con inizializzazione: constraint violation
	int dati[ n ] = { 1 };

	for ( int i = 0 ; i < n ; i++ )
		scanf( "%d", &dati[ i ] );

}
 */

/*
	Questa funzione dimostra che la lunghezza di un VLA può essere 
	un'espressione che viene calcolata a tempo di esecuzione
*/
void vla_lunghezza_2( void ) {

	struct T {
		unsigned char voto;
		bool primo_anno;
	};

	int n, m;

	printf( "\n\nTest vla_lunghezza_2\n" );

	// legge quanti voti di studenti del primo anno devono essere registrati
	printf( "Quanti voti del I anno inserire? " );
	scanf( "%d", &n );

	// legge quanti voti di studenti di anni successivi al primo devono essere registrati
	printf( "Quanti voti di anno successivo al I inserire? " );
	scanf( "%d", &m );

	// dichiarazione VLA la cui lunghezza è un'espressione
	struct T voti[ n + m ];

	// verifica correttezza sizeof
	if ( n + m == sizeof voti / sizeof voti[ 0 ] )
		printf( "\n\n\t\tIl prof. ha ragione, sizeof funziona anche con i VLA!\n\n\n" );

	// inserimento voti I anno
	for ( int i = 0 ; i < n ; i++ ) {
		printf( "Inserire un altro voto (I anno): ");
		scanf( "%hhd", &voti[ i ].voto );
		voti[ i ].primo_anno = true;
		printf( "\n" );
	}

	// inserimento voti anni successivi al I
	for ( int i = 0 ; i < m ; i++ ) {
		printf( "Inserire un altro voto (anni successivi): ");
		scanf( "%hhd", &voti[ n + i ].voto );
		voti[ n + i ].primo_anno = false;
		printf( "\n" );
	}

	// ordina voti (algoritmo selection sort)
	for ( int i = 0 ; i < n + m ; i++ ) {
		for ( int j = i + 1 ; j < n + m ; j++ ) {
			if ( voti[ j ].voto > voti[ i ].voto ) {
				struct T t;
				t =  voti[ i ];
				voti[ i ] = voti[ j ];
				voti[ j ] = t;
			}
		}
	}

	// stampa voti ordinati
	printf( "\nElenco voti\n" );
	for ( int i = 0 ; i < n + m ; i++ ) {
		printf( "%d", voti[ i ].voto );
		if ( voti[ i ].primo_anno ) printf( "\tI anno\n" );
		else printf( "\n" );
	}
	printf( "\n" );

}

/*
	Questa funzione dimostra che non è possibile modificare la lunghezza di
	un VLA successivamente alla sua allocazione
*/
void vla_lunghezza_1( void ) {

	printf( "\n\nTest vla_lunghezza_1\n" );

	// legge da standard input quanti valori devono essere registrati
	int n;
	printf( "Quanti dati inserire? " );
	scanf( "%d", &n );

	// dichiarazione VLA
	int dati[ n ];

	// verifica che la lunghezza del VLA viene calcolata correttamente
	// usando sizeof (come per gli array statici)
	printf( "Ora n vale %d e la lughezza del VLA ", n );
	printf( "(calcolata con sizeof) è %zu\n", sizeof dati / sizeof dati[ 0 ] );

	// modifica di n
	n += 2;

	// verifica che la variazione del valore di n non ha
	// modificato la lunghezza del VLA
	printf( "Ora n vale %d e la lughezza del VLA ", n );
	printf( "(calcolata con sizeof) è %zu\n", sizeof dati / sizeof dati[ 0 ] );

}


/*
	Questa funzione dimostra che è possibile dichiarare un VLA anche dentro
	un blocco annidato, in questo caso il corpo di un ciclo: il VLA viene
	allocato ogni volta che si esegue il blocco e de-allocato dopo aver eseguito
	l'ultima istruzione del blocco.
*/
void vla_blocco( void ) {

	printf( "\n\nTest vla_blocco\n" );

	// legge quante serie di dati si vogliono inserire
	int k;
	printf( "Quante serie di dati inserire? " );
	scanf( "%d", &k );

	for ( int h = 0 ; h < k ; h++ ) {
		// legge da standard input quanti valori devono essere registrati
		int n;
		printf( "\nQuanti dati in questa serie? " );
		scanf( "%d", &n );

		// alloca VLA e legge i dati, calcolando quanti sono maggiori del valor medio
		int dati[ n ], contatore = 0;
		float media = 0;
		for ( int i = 0 ; i < n ; i++ ) {
			printf( "Inserire un altro dato: ");
			scanf( "%d", &dati[ i ] );
			media += dati[ i ];
		}
		media /= n;
		for ( int i = 0 ; i < n ; i++ ) 
			if ( dati[ i ] > media ) contatore++;
		printf( "In questa serie ci sono %d dati maggiori del valor medio\n",
			contatore );

	}
	printf( "\n" );

}

int main( void ) {

	vla_lunghezza_1();

	vla_lunghezza_2();

	vla_blocco();

	return 0;
}
