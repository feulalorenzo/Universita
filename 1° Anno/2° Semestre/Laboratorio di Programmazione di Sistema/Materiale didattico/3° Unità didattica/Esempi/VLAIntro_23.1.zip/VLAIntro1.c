/*
	LPS Example

	VLA Intro 1

	Language: C99
 	Style: plain C
 	Version: LPS23-pc
*/

/*
	Definizioni di VLA
*/

#include <stdio.h>

/*
	Gli array dichiarati esternamente, come tutte le variabili esterne 
	vengono creati prima che inizi il programma, ovvero hanno
	storage duration statica.
	Pertanto sia la lunghezza che il contenuto devono essere valori costanti.
*/

/*
	Questa funzione mostra un esempio di definizione di un VLA, attraverso l'analisi
	dei voti registrati in un appello d'esame

	La funzione chiede legge da standard input il numero di vosti da
	registrare e dichiara un VLA di lunghezza pari al numero letto.
	Poi calcola il valor medio dei voti inseriti e quanti voti risultano 
	superiori al voto medio.
*/
void def_VLA( void ) {
	// legge da standard input quanti valori devono essere registrati
	int n;
	printf( "Quanti voti inserire? " );
	scanf( "%d", &n );

	int voti[ n ], i; 		// dichiarazione VLA

	// legge da input i voti
	float media = 0;
	i = 0;
	do {
		int v;
		printf( "Che voto registrare (numero compreso tra 0 e 30)? " );
		scanf( "%d", &v );
		if ( 0 <= v && v <= 30 ) {
			voti[ i++ ] = v;
			media += v;			// accumula somma dei voti
		}
	} while ( i < n );

	media /= n;		// completa calcolo media

	// calola quanti voti sono superiori alla media
	int c = 0;
	for ( i = 0 ; i < n ; i++ )
		if ( voti[ i ] > media ) c++;
	printf( "Sono stati registrati %d voti superiori alla media\n", c );

	return;
}

int main( void )
{

	def_VLA();
	return 0;
}
