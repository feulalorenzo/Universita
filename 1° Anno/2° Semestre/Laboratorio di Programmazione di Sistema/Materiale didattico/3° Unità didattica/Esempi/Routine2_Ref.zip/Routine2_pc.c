/*
	LPS Example

	Routine 2

	Language: C89
 	Style: plain C
 	Version: Ref-pc
 */

/*
	Original Plain C Code
*/

/*
	Questo esempio viene usato per mostrare come realizzare una routine foglia
	che accetta parametri e restituisce un risultato;
	parametri e risultato vengono comunicati usando dei registri

	In particolare si mostra la traduzione di una funzione C che prende in
	ingresso due valori di tipo int b ed n e, assumendo che sia n >= 0, calcola b^n.
*/

int power( int b, int n ) {
	int i = 0, c = 1;
	while ( i < n ) {
		c = c * b;
		i++;
	}
	return c;
}

int k;

int main( void ) {

	k = power( 3, 2 );
	k = power( k, 3 );
	k = power( 2, 12 );
	return 0;
}
