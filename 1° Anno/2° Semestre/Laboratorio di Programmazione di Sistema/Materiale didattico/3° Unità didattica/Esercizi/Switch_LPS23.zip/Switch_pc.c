/*
	LPS Example

	Switch

	Language: C99
 	Style: plain C
 	Version: Ref-pc
 */

/*
	Original Plain C Code
*/

/*
  Questo esempio mostra come tradurre in ASM
  un programma C che contiene un'istruzione switch
*/

#include <stdio.h>

int a = 4, b = 10, c = 20, x = -2;

int main(void) {

	scanf( "%d", &x );

	switch( x ) {
	
	case 0:
		a = -4;
		break;
	case -3:
		b = 0xDEADC0DE;
		break;
	case 2:
		c = a + b;
		/* questo caso va a finire (fall-through) nel caso 3 */
	case 3:
		b = c - 2;
		break;
	case -1:
		b += x + 3;
		/* questo caso va a finire (fall-through) nel caso 4 */
	case 4:
		c = 20;
		a = b;
		break;
	default:
		--a;
	}
	x = a + b + c;
	printf( "%d\n", x );

	return 0;
}

/*
	Test Cases

	Test 1
	input: -2
	output: 33

	Test 2
	input: -1
	output: 44

	Test 3
	input: 0
	output: 26

	Test 4
	input: 1
	output: 33

	Test 5
	input: 2
	output: 30

	Test 6
	input: 3
	output: 42

	Test 7
	input: 4
	output: 40

	Test 8
	input: 5
	output: 33

	Test 9
	input: -3
	output: -559038218

	Test 10
	input: -9
	output: 33
*/
