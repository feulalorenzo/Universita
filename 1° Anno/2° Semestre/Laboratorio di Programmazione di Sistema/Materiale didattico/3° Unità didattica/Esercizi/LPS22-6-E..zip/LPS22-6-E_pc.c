#include <stdio.h>

struct T {
	long x;
	unsigned char c1,c2;
	int y;
} a[ 10 ];


int main( void ) {

	// ciclo lettura

	// ordinamento
	int i, j;
	for ( j = 1 ; j < 10 ; j++ ) {
		struct T key = a[ j ];
		i = j - 1;
		while ( i > 0 && a[ i ].c1 > key.c1 ) {
			a[ i + 1 ] = a[ i ];
			i = i - 1;
		}
		a[ i + 1 ] = key;
	}

	// ciclo di stampa

	return 0;
}