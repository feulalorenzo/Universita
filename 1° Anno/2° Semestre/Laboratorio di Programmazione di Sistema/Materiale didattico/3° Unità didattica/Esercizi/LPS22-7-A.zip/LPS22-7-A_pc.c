/*
	LPS Exam Solution

	LPS22-AP7 exercise A

	Language: C99
 	Style: plain C
 	Version: LPS23
*/

#include <stdio.h>

int a[ 10 ], x;

int main( void ) {

	for ( int *p = a ; p < a + 10 ; p++ )
		scanf( "%d", p );

	x = 0;
	for ( int i = 0 ; i < 12 && x <= 1000 ; i++ ) {
		int y = a[ x ];
		x += a[ y % 10 ];
	}

	for ( int *p = a ; p < a + 10 ; p++ )
		if ( *p > x ) printf( "%d", *p );

/* versione con indice
	for ( int i = 0 ; i < 10 ; i++ )
		if ( a[ i ] > x ) printf( "%d", a[ i ] );

*/

	return 0;
}