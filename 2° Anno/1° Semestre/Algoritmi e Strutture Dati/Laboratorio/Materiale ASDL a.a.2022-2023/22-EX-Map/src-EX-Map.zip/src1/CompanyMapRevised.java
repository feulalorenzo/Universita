/* EX1
Suppose we are given the name and division number for each employee in a company.
There are no duplicate names. We would like to store this information alphabetically, by name. 
How should this be done? 
TreeMap? TreeSet? Comparable? Comparator? 
*/

import java.util.*;

class CompanyMapRevised
{
    public static void main(String[ ] args)
    {

	TreeMap<String, Integer> companyMap = 
		new TreeMap<String, Integer>();

        companyMap.put ("Misino John", 8);
        companyMap.put ("Nguyen Viet", 14);
        companyMap.put ("Panchenko Eric", 6);
        companyMap.put ("Dunn Michael", 6);
        companyMap.put ("Deusenbery Amanda", 14);
        companyMap.put ("Taoubina Xenia", 6);

        System.out.println ("\nCompany:\n" + companyMap);

	System.out.println ("\nDivision number 6:\n");
	
	// ITERAZIONE SULLA COLLECTION VIEW!
	
	for (Map.Entry<String, Integer> entry : companyMap.entrySet()) {
		// entry � una specifica coppia chiave-valore <k,v>  
	    if (entry.getValue() == 6)  System.out.println (entry);
	}

    	System.out.println ("\nEmployees:\n" + companyMap.keySet());

    	System.out.println ("\nDivision numbers:\n" + new TreeSet<Integer>(companyMap.values()));

        /***  REVISED!  
         * Obiettivo: contare il numero di impiegati assegnati ad
         * ogni ufficio (numero di occorrenze) ***/

    // Uso mappa Map<Integer, Integer> di coppie <Division number, number of employees> 
	TreeMap<Integer, Integer> companyCount =  new TreeMap<Integer, Integer>();
	
	// Inizializzo companyCount assegnando il valore zero ad ogni division number
	Collection<Integer> DivisionNumbers = companyMap.values(); 	
	//HashSet<Integer> DivisionNumbers = new HashSet<Integer>(companyMap.values()); 
	for (Integer dn : DivisionNumbers)
	    companyCount.put(dn,0);  // inserisce <6,0>, <8,0>, <14, 0>

	// Scorro le coppie in companyMap, con associazioni <impiegato, Division number>,
	// estraendo il division number
	for (Map.Entry<String, Integer> entry : companyMap.entrySet()) {
		Integer currentDivisionNumber = entry.getValue(); 
		Integer currentOccurrency =  companyCount.get(currentDivisionNumber);
	    companyCount.replace(currentDivisionNumber, currentOccurrency + 1 );  // anche put
	}

	System.out.println (companyCount);


    } // method main                                   
    

} // class CompanyMap
