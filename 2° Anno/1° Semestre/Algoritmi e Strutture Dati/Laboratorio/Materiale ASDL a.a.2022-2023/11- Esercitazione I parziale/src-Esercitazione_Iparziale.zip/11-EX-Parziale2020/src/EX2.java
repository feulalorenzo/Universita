import java.util.*;

public class EX2 {
	
	/* L'esercizio 2 richiede l'implementazione di due metodi nella classe Espressione:
	 * -   public int gradoE() che calcola il grado dell'espressione
	 * -   il metodo di confronto appropriato tra due espressioni
	 * 
	 */

	 public static void ordinaE(ArrayList<Espressione> listOfExpr) {
		   Collections.sort(listOfExpr);
	   }

}
