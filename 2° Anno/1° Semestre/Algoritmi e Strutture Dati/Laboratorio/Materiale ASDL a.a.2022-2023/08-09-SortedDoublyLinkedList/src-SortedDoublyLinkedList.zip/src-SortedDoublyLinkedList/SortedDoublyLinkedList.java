/***************************************************************************
 * 
 * SortedDoublyLinkedList.java
 *
 * More advanced implementation of the Collection interface using a doubly
 * linked list with references to both the head and tail Node's in the list.
 * It implements a sorted list.
 * Here Sorted list is implemented using a doubly linked list 
 * and each inserted element is placed at correct position in the list. 
 *
 *****************************************************************************/

   /********************************************************************
   					             I PARTE
   ********************************************************************/ 

import java.util.*;


public class SortedDoublyLinkedList<E extends Comparable<? super E>> implements Collection<E> {
// Remark: Implemented Interface: java.lang.Iterable<E> 
	

 /*******************************************************
 *
 *  The Node class
 *
 ********************************************************/
   private static class Node<E> {
	   private E data;
	   private Node<E> next;
	   private Node<E> prev;

      public Node(E data, Node<E> next, Node<E> prev) {
         this.data = data;
         this.next = next;
         this.prev = prev;
      }
   }  //end-class-Node
   
      
   private Node<E> head = null;
   private Node<E> tail = null;
   private int size = 0;
   private Comparator<? super E> c = null;

   /**
    *  Constructs an empty list
    */
    public SortedDoublyLinkedList() { }
    
    /**
     *  Constructs an empty list
     */
    public SortedDoublyLinkedList(Comparator<? super E> comparator) 
    {
      c = comparator;
    }
    
  /**
   *  Returns true if the list is empty
   */
   public boolean isEmpty()  {  return size == 0; }

  /**
   *  Returns the length of the list
   */
   public int size()  { return size; }
   
  /**
   *  Gets the value of the property comparator
   */
   Comparator<? super E> getComparator()  { return c; }
   
   /**
    *  Returns the first element in the list.
    *
    */
   public E getFirst()
   {
	   if(head == null) throw new NoSuchElementException();
       return head.data;
   }

  /**
    *  Removes the first element in the list.
    *
    */
    public E removeFirst()
    {
 	  if (head == null) throw new NoSuchElementException(); // size == 0
       E elem = head.data;
       head = head.next;
       if (head == null) tail = null; // empty list
       else head.prev = null;
       size--;
       return elem;
    }
    
    /**
     *  Returns the last element in the list.
     *
     */
     public E getLast()
     {
        if (tail == null) throw new NoSuchElementException(); // size == 0
        return tail.data;
     }


   /**
     *  Removes the last element in the list.
     *
     */
     public E removeLast()
     {  
    	 if (tail == null) throw new NoSuchElementException();  // size == 0
    	 E elem = tail.data;
    	 if (size == 1) return removeFirst();
    	 else { // there are at least two nodes
    		 tail = tail.prev;
    		 tail.next = null;
    		 size--;
    	 }
    	 return elem;
     }


   /**
     *  Removes all nodes from the list.
     *
     */
     public void clear()
     {
    	 head = tail = null; size=0;
     }

   /**
     *  Returns the data at the specified position in the list.
     *
     */
     public E get(int index)
     {
        if (head == null || index < 0 || index > size - 1 ) throw new IndexOutOfBoundsException();
        Node<E> cur;
        int count;
        // la direzione dell'iterazione dipende dalla posizione index
        if (index <= size/2) for (cur = head, count = 0; count < index; count++) cur = cur.next;
        else for (cur = tail, count = size-1; count > index; count--) cur = cur.prev; 
        return cur.data;
     }


   /**
     *  Returns a string representation
     *
     */
     public String toString()
     {
    	 StringBuffer result = new StringBuffer();  
    	 for(Object x : this) result.append(x + "; ");
    	 return result.toString();
     }
        

   /**
     *  Removes the first occurrence of the specified element in this list.
     *
     */
     
     private boolean lessThan(E x, E y){
    	   if (c == null) return (x.compareTo(y) < 0);
    	   else return (c.compare(x, y)) < 0;
     }
     
     public boolean remove(Object key)
     {
    	 return false;
     }
     
     
     public boolean remove(E key)
     {
    	 if ( key == null || head == null || lessThan(key, head.data) ) return false;

    	 Node<E> cur  = head;
    	 while(cur != null && lessThan(cur.data, key)) cur = cur.next;
    	 //  this list does not contain the specified element,
    	 if(cur == null || !cur.data.equals(key)) return false;
    	 // removes the first occurrence of the specified element from this list,
    	 if (cur == head) removeFirst();
    	 else if (cur == tail) removeLast();
    	 else {
    		 cur.prev.next = cur.next;
    		 cur.next.prev = cur.prev;
    		 size--;
    	 }
    	 return true;	
     }
     
     /**
      *  Removes the first occurrence of the specified element in this list.
      *  (for teaching purposes)
      *
      */
      public boolean removeRec (E key)
      {
         if ( (key == null) || (head == null) || lessThan(key, head.data) ) return false;
         if (head.data.equals(key)) { 
       	  removeFirst();
       	  return true; 
         } else return removeRec(head.next, key);
      }


      private boolean removeRec (Node<E> cur, E key){
         if (cur == null ||  lessThan(key, cur.data) ) return false;
         if (cur.data.equals(key)) {
      	    if (cur == tail) removeLast();
      	    else {
      	    	  cur.prev.next = cur.next;
      	    	  cur.next.prev = cur.prev;
      	    	  size--;
      	    }
       	  return true;
         }
         else return removeRec(cur.next, key);
          	
      }
      
      
      
      /**
       *  Removes the element at the specified position in this list
       */   
      public E remove (int index) {
    	  if ((head == null) || (index < 0) || (index > size-1)) throw new IndexOutOfBoundsException(); 
    	  if (index == 0) return this.removeFirst();
    	  if (index == size-1) return this.removeLast();
    	  // 1 <= index <= size-2
          Node<E> cur = head.next; // index 1          
          for (int count = 1; count < index; count++) cur = cur.next;  //migliorabile
          //removes current node
      	  E item = cur.data;
      	  cur.prev.next = cur.next;
          cur.next.prev = cur.prev;
          size--;
          return item;
      }
              
      /**
       *  Returns true if this list contains the specified element.
       *
       */
      public boolean contains(Object x) {return false;}
      
      public boolean contains(E key)  
       {
    	  for(E curEl : this)
       			if(curEl.equals(key)) return true;
       			else if (lessThan(key, curEl)) break;
          return false;
       }
      
    
   /** Inserts the element into the proper sorted location.
    */
   public boolean add(E item)
   { 
	   return add(item,c);
   }
   
   private boolean add(E item, Comparator<? super E> comparator) { 
	   
	   if (item == null) return false; 
	   // we insert the first element
	   if (size == 0) {  
		   tail = head = new Node<E>(item, null, null);
		   size++;
		   return true;
  	   }
	   // we insert the element at the first position 
	   if (lessThan(item, head.data)) {  
		   head = new Node<E>(item, head, null);
		   head.next.prev = head;
		   size++;
		   return true;
	   }
	   // we insert the element into the proper sorted location   
  	   Node<E> cur = head;
  	   /* We continue until cur reaches the node before which we need to make an insertion:
  	    * if cur reaches null, we insert the element at the last position (after tail), 
		* otherwise we insert the element between prev and cur
  	    */
  	   while (cur!= null && lessThan(cur.data, item)) cur = cur.next;
  	   if (cur == null) {
  		   // inserts the element at the last position
  		   tail.next = new Node<E>(item, null, tail);
  		   tail = tail.next;
  	   } else { 
  		   // (cur.data >= item) inserts the element between prev and cur
  		   Node<E> prev = cur.prev;
  		   Node<E> newnode = new Node<E>(item, cur, prev);
  		   cur.prev = newnode;
  		   // remark: prev could be null if item is equal to the first element
  		   if (prev!=null) prev.next= newnode; else head =  newnode;
  	   }
  	   size ++;
  	   return true;
   } //end-add 
    

   
   /********************************************************************
   					             II PARTE
   ********************************************************************/   					
   
       
    /**
      *  A Comparator based ordering method
      */
     
   public SortedDoublyLinkedList<E> insertionSort()
   /* if comparator is null we sort the list into ascending order, according to
    * the natural ordering of its elements.
    */
   {
	   return insertionSort(null);
   }
     
   /**
	 * Sorts the list according to the order induced by the specified comparator.
	 */
   public SortedDoublyLinkedList<E> insertionSort(Comparator<? super E> comparator) //O(n^2)
   {
	   SortedDoublyLinkedList<E> list = new SortedDoublyLinkedList<E>();
       for (E item: this)  list.add( item, comparator);
       return list;
   }
   
   
   /**
    * toArray() method returns an array containing all of
    * the elements in this list in proper sequence (from
    * first to last element). 
    * */ 

    public Object[] toArray() {
 	   if (head == null) return null;
        Object[] array = new Object[size];
        int i=0;	
        for (E item: this) {array[i++] = item; }
        return array;
      }
   
    
   private void append(E item) {
	   if (size == 0) head = tail = new Node<E> (item, null, null);
	   else {
		   tail.next = new Node<E>(item, null, tail);
		   tail = tail.next;
	   }
	   size++;
   }
   
   public SortedDoublyLinkedList<E> sort() //O(n lgn)
   {
	   return sort(null);
   }
   
   public SortedDoublyLinkedList<E> sort(Comparator<? super E> comparator) //O(n lgn) Mergesort-based
   {
	   if (this.isEmpty()) return this;
	   List<E> array = new ArrayList<E>(this);
       if (comparator == null) Collections.sort(array); 
       else  Collections.sort(array, comparator);
	   SortedDoublyLinkedList<E> list = new SortedDoublyLinkedList<E>();
	   // for (E item: array) list.add(item);  // inefficiente O(n^2)
	   for (E item: array) list.append(item);
	   return list;
   }
   /* NOTA In sort si potrebbe usare un array come: Object[] array = this.toArray()
      Tuttavia si rilevano warnings (unchecked cast from Object to E) e si hanno problemi run time
      Preferibile usare ArrayList<E> */
   
      
      
   /**
     *  Sets the value of the property comparator
     */
   public void  setComparator(Comparator<? super E> comparator)
   	{
   		//SortedDoublyLinkedList<E> list = insertionSort(comparator); //O(n^2)
   		SortedDoublyLinkedList<E> list = sort(comparator); //O(n log n)
        c = comparator;
        head = list.head;
        tail = list.tail;
   	}
   
   
   public boolean equals (Object obj) {
	   return (this == obj);
   }


   
   /*******************************************************
   *
   *  The Iterator class
   *
   ********************************************************/
   
     public Iterator<E> iterator()
     {
        return new DoublyLinkedListIterator();
     }

     
     /** 
      * Returns a list iterator over the elements in this list (in proper sequence)
      * 
      */
     public ListIterator<E> listIterator()
     { 
         return new DoublyLinkedListIterator();   
     }
     
     public ListIterator<E> listIterator(int index)
     { 
         return new DoublyLinkedListIterator(index);   
     }


     private class DoublyLinkedListIterator  implements ListIterator<E>
     {
    	 private Node<E> nextNode;
    	 private int posNext;

        public DoublyLinkedListIterator()
        {
        	nextNode = head;
        	posNext = 0;  
        }
        
        public DoublyLinkedListIterator(int index)
        {
        	if ((index < 0) || (index > size)) throw new IndexOutOfBoundsException(); 
      	  	if (index == size) {
      	  		nextNode = null;
      	  		posNext = index;
      	  	} else {
      	  		nextNode = head;
      	  		posNext = 0;  
      	  		for (; posNext<index; posNext++) nextNode = nextNode.next;
      	  	}
        }

        public boolean hasNext()
        {
           return nextNode != null;
        }
        
        public boolean hasPrevious() 
        { 
        	if (nextNode == null) return (tail != null);
        	else return nextNode.prev != null;
        }	

        public E next()
        {
           if (!hasNext()) throw new NoSuchElementException();
           E res = nextNode.data;
           nextNode = nextNode.next;
           posNext++;
           return res;
        }
        
        public E previous()
        {
            if (!hasPrevious()) throw new NoSuchElementException();
        	if (nextNode == null) nextNode = tail;
        	else nextNode = nextNode.prev;
            posNext--;
            return nextNode.data;
        }

        public void remove() {
        	// non si � ancora invocato next()
        	if (nextNode == head) throw new NoSuchElementException(); // posNex==0
       	  	if (posNext == 1) {
       	  		head=head.next;
       	  		head.prev = null;
       	  	}
       	  	// cancellazione del nodo in posizione posNext-1
       	  	else {
       	  		if (nextNode == null) {
       	  			tail = tail.prev; 
       	  			tail.next = null;
       	  			
       	  		}
       	  		else {
       	  			Node<E> prevNode = nextNode.prev.prev;
           	  		prevNode.next = nextNode;
           	  		nextNode.prev = prevNode;
       	  		}

       	  	}
       	  	posNext--;
            size--;
        }
               
        public void add(E e)
 	   	{
        	if (nextNode == null) {
        		tail.next = new Node<E>(e, null, tail);
        		tail=tail.next;
        	}
        	if (nextNode == head) { // posNex==0
        	      head = new Node<E>(e, head, null);
        	      nextNode.prev = head;  
        	} else {
        		Node<E> prevNode = nextNode.prev;
        		prevNode.next = new Node<E>(e, nextNode, prevNode);
        		nextNode.prev = prevNode.next; 
        	}
  	      size++;
  	      posNext++;
 	   		
 	   	}
        
        /* Esercizio: Implementare su liste doppiamente collegate */
  
        public int nextIndex()
 	   	{ throw new UnsupportedOperationException(); }
        
        public int previousIndex()
 	   	{ throw new UnsupportedOperationException(); }
        
        public void set(E e)  // operazione vietata dato che potrebbe violare l'ordinamento
        { throw new UnsupportedOperationException(); }

     }  //end class LinkedListIterator

      
      
   public boolean retainAll(Collection<?> c)
   { throw new UnsupportedOperationException(); }

   public boolean removeAll(Collection<?> c)
   { throw new UnsupportedOperationException(); }
   
   public boolean containsAll(Collection<?> c)
   { throw new UnsupportedOperationException(); }

   public <T> T[] toArray(T[] a)
   { throw new UnsupportedOperationException(); }
   
    public E set(int index, E element)
    { throw new UnsupportedOperationException(); }  
    

    
    /********************************************************************
       II PARTE: esercitazione
     ********************************************************************/ 
    
    
    /**
     *  Due liste sono uguali se contengono elementi uguali nelle stesse posizioni 
     *  Complexity: O(n)
     *  per esercizio riscrivere con append
     */
    public boolean equals (SortedDoublyLinkedList<E> obj) {
	   if (obj == null) return false;
	   Iterator<E> itr1 =  this.iterator();
	   Iterator<E> itr2 = obj.iterator();
	   if (this.size != obj.size) return false;
	   while (itr1.hasNext())
		   if ( !itr1.next().equals(itr2.next()) ) return false;
	   return true;
   }
    
    
   
    /**
     *  Returns a copy of the list
     *  Complexity: O(n)
     */
   public  SortedDoublyLinkedList<E> copy()
   {
	   SortedDoublyLinkedList<E> twin = new SortedDoublyLinkedList<E>();
	   if (size == 0) return twin;
       Iterator<E> itr = this.iterator();
       // add first node
       twin.tail = twin.head = new Node<E>(itr.next(), null, null);
       twin.size++;
       while (itr.hasNext()) {
    	   // addLast
           twin.tail.next = new Node<E>(itr.next(), null, twin.tail);
           twin.tail = twin.tail.next;
           twin.size++;
       }
       return twin;
   }
   
   
   //  implementazione basata su append()
   public  SortedDoublyLinkedList<E> copy2()
   {
	   SortedDoublyLinkedList<E> twin = new SortedDoublyLinkedList<E>();
	   for (E item: this) twin.append(item);
       return twin;
   }
   
   
   /*	EX3 Parziale 2020
    * Implementare il metodo public boolean addAll(Collection<? extends E> c), 
    * interno alla classe SortedDoublyLinkedList, che inserisce nella lista corrente (this)
    * tutti gli elementi nella collezione specificata in modo da non violare l'ordinamento.
    */
     public boolean addAll(Collection<? extends E> c) {
  	   if (c == null || c.isEmpty()) return false;
  	   for (E item: c) add(item);
  	   return true;
     }
    
   
} // end-class 