interface Ordinabile 
{
	 /**
	  * Il metodo dovr� restituire un valore positivo se questo oggetto �
	  * maggiore di quello specificato (ovvero "segue" il secondo nella sequenza di ordinamento),
	  * un valore negativo se questo oggetto � minore di quello specificato, 0 altrimenti.
	  */
	 public int confronta (Ordinabile obj);
}