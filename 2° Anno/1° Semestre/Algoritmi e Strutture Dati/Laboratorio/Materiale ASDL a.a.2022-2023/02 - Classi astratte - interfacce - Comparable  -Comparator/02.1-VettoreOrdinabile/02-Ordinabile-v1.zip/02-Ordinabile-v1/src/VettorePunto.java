public class VettorePunto extends VettoreOrdinabile {
	
	public VettorePunto () {
		super (10); 
	}
	
	public VettorePunto (int maxDim) {
		super (maxDim);
	}

	// questo metodo impedisce l'inserimento di oggetti di tipo diverso da Punto
	public boolean aggiungi (Object elemento) {
		return false; 
	}
 
	public boolean aggiungi (Punto elemento) {
		return super.aggiungi(elemento);
	}

	//definizione del metodo astratto
	@Override
	protected int confronta (Object elemento1, Object elemento2) {
 		Punto p1, p2;
 		p1 = (Punto) elemento1;
 		p2 = (Punto) elemento2;
 		if (p1.equals(p2)) return 0; 
 		else {
 			if (p1.maggioreDi(p2))
 				return 1;
 			else return -1;
 		}
	}

	/** il metodo ordina e visualizza l'array di oggetti Punto */
	public void visualizza(){
		this.ordina();
		for (int i=0; i<this.dim(); i++) System.out.println(leggi(i));
	}


}
