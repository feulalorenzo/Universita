public abstract class VettoreOrdinabile {
	
	   private Object vettore[];
	   private int maxDim;  //dimensione massima
	   private int curDim;  //dimensione effettiva

	public VettoreOrdinabile (int maxDim) {
	    this.maxDim = maxDim;
		vettore = new Object[maxDim];
		curDim = 0;
	   }

	public boolean aggiungi (Object elemento) {
	    if (elemento != null && curDim < maxDim) {
		   vettore[curDim++] = elemento;
	       return true;
	    } else return false;
	 }

	 public Object leggi (int indice) {
	    if (indice >= 0 && indice < curDim)
		   return (vettore[indice]);
		else return null;
	 }
	 
	 public int dim () { return curDim; }

	 public void ordina () {   //shell-sort
	     int   s, i, j, num;
	     Object temp;
	     num = curDim;
	     for (s = num / 2; s > 0; s /= 2)
	        for (i = s; i < num; i++)
	           for (j = i - s; j >= 0; j -= s)
	              if (confronta (vettore[j], vettore[j + s]) > 0) {
	                 temp = vettore[j];
	                 vettore[j] = vettore[j + s];
	                 vettore[j + s] = temp;
	              }
	  }
	 
 	
	 /**
	  * Il metodo dovr� restituire un valore positivo se il primo argomento �
	  * maggiore del secondo (ovvero "segue" il secondo nella sequenza di ordinamento),
	  * un valore negativo se il primo argomento � minore del secondo, 0 altrimenti.
	  */
	 protected abstract int confronta (Object elemento1, Object elemento2);

	}


