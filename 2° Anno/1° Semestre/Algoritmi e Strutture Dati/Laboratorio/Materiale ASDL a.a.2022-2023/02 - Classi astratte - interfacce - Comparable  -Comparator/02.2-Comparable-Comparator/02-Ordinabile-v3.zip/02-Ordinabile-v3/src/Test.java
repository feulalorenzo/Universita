
public class Test {

	public static void main(String[] args) {

		  VettoreOrdinabile<Punto> vo = new VettoreOrdinabile<Punto>(10);
	      vo.aggiungi (new Punto(30,40));
	      vo.aggiungi (new Punto(300,400));
	      vo.aggiungi (new Punto(3,4));
	      
		  //stampa array ordinato
	      vo.ordina();
		  System.out.println("VettorePunto:");
		  vo.visualizza();
		  
		  
		  VettoreOrdinabile<Intero> vo2 = new VettoreOrdinabile<Intero>(10);
	      vo2.aggiungi (new Intero(34));
	      vo2.aggiungi (new Intero(10));
	      vo2.aggiungi (new Intero(45));
	      vo2.aggiungi (new Intero(7));
	      
		  //stampa array ordinato
	      vo2.ordina();
		  System.out.println("VettoreIntero:");
		  vo2.visualizza();
		  
		  
		  
		  
		  
	}

}
