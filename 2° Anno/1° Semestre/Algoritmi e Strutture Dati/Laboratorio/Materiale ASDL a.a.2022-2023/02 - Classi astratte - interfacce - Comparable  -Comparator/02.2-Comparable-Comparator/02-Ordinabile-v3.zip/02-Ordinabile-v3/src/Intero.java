class Intero implements Comparable<Intero>{

   private int intValue;

   public Intero(int x){ intValue=x; }	

   public int getValue(){ return intValue; }
   
  	@Override
  	public String toString() {
  		return String.valueOf(intValue);
  	}
  	
   	@Override
   	public boolean equals(Object obj) {
   		if (obj == null || !(obj instanceof Intero)) return false;
   		return intValue == ((Intero)obj).getValue();
   	}
  	
   	@Override
  	public int compareTo (Intero x) {
 		if (x == null) throw new NullPointerException("L'oggetto specificato � null");
 		return intValue - x.getValue();
  	}
  	
  //completare
  	
}