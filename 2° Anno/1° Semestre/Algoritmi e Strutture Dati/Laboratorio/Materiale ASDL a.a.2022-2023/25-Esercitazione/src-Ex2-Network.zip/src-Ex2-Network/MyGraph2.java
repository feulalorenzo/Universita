/**
 * Esercizio 2 del 21.01.2021 (II parziale)
 * Si assuma una classe MyGraph con una sola variabile d�istanza private 
 * Network<String> myGraph (non sviluppare il codice). 
 * Si implementi un metodo public LinkedList<String> ListOfNodes() interno
 * alla classe MyGraph, che restituisce la lista in ordine lessicografico
 * crescente dei nodi contenuti in questa istanza.
 */

	
import java.util.*;

public class MyGraph2 {
	
	Network<String> myGraph;
	/** altro codice non richiesto */
	
	public LinkedList<String> ListOfNodes(){
		LinkedList<String> list = new LinkedList<String>();
		if (myGraph.isEmpty()) return list;
		Iterator<String> itr = myGraph.iterator();
		while (itr.hasNext()) list.add(itr.next());
		return list;
	} 
		
	
}