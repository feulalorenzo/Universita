	
	/***
	 * Esercizio 2 del 5.9.2017
	 * Si assuma una classe MyGraph<E> con una sola variabile d�istanza private
	 * Network<Integer> myGraph (non sviluppare il codice).
	 * Si implementi un metodo public boolean IsPath(LinkedList<Integer> list);
	 * interno alla classe, che data una lista di oggetti interi verifichi se
	 * la lista rappresenta un cammino sul grafo corrente.
	 * 
	 ***/

	
import java.util.*;

public class MyGraph {
	
	Network<Integer> myGraph;
	/** altro codice non richiesto */
	
	public boolean IsPath(LinkedList<Integer> list){
		Integer v1, v2; 
		boolean ispath = true;
		if (list.isEmpty()) return ispath;
		Iterator<Integer> itr = list.iterator();
		v1 = itr.next();
		while (itr.hasNext() && ispath) {
			v2 = itr.next();
			if (myGraph.containsEdge(v1, v2)) v1 = v2;
			else ispath = false;
		}
		return ispath;
	} 
		
	
}

	
