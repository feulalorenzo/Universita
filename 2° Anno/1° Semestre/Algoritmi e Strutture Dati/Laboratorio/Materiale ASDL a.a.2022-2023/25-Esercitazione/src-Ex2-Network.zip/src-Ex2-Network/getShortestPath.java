/***** Add to the class Network<Vertex>  *****/ 

    /**
     *  Finds a shortest path between two specified vertices in this Network
     *  object (non-negative weights).
     *  The worstTime(V, E) is O(E log V).
     *
     *  @param v1 - the beginning Vertex object.
     *  @param v2 - the ending Vertex object.
     *
     *  @return a LinkedList object containing the vertices in a shortest path
     *                from Vertex v1 to Vertex v2.  The last element is the
     *                weight of the path, or -1.0 if there is no path.
     *
     */
    public LinkedList<Object> getShortestPath (Vertex v1, Vertex v2)
    {
        final double MAX_PATH_WEIGHT = Double.MAX_VALUE;

        HashMap<Vertex,Double> weightSum = new HashMap<Vertex,Double>();
        HashMap<Vertex,Vertex> predecessor = new HashMap<Vertex,Vertex>();
        PriorityQueue<VertexWeightPair> pq = new PriorityQueue<VertexWeightPair>();

        VertexWeightPair vertexWeightPair;
        double weight;
 
        if (v1 == null || v2 == null)
            throw new NullPointerException();
        if (! (adjacencyMap.containsKey (v1) && adjacencyMap.containsKey (v2)))
            return new LinkedList<Object>();
        
        for(Vertex vertex: adjacencyMap.keySet()) {
            weightSum.put (vertex, MAX_PATH_WEIGHT);
            predecessor.put (vertex, null);
        } // initializing weightSum and predecessor
        weightSum.put (v1, 0.0);
        predecessor.put (v1, v1);
        pq.add (new VertexWeightPair (v1, 0.0));

        boolean pathFound = false;
        while (!pathFound && !pq.isEmpty())  {

            Vertex from, to = null;
            vertexWeightPair = pq.remove();
            from = vertexWeightPair.vertex;
            if (from.equals (v2))
                pathFound = true;
            else if (vertexWeightPair.weight <= weightSum.get(from)) 
            {                  
                for (Map.Entry<Vertex, Double> entry : adjacencyMap.get (from).entrySet())
                {
                     to = entry.getKey();
                     weight = entry.getValue();
                     if (weightSum.get (from) + weight < weightSum.get (to)) 
                     {
                         weightSum.put (to, weightSum.get (from) + weight);
                         predecessor.put (to, from);
                         pq.add (new VertexWeightPair (to,weightSum.get (to)));
                     } // if
                 } // while from's neighbors have not been processed
            } // else path not yet found
        } // while not done and priority queue not empty

        LinkedList<Object> path = new LinkedList<Object>();
        if (pathFound)  {
            Vertex current = v2;
            while (!(current.equals (v1)))  {
                path.addFirst (current);
                current = predecessor.get (current);
            } // while not back to v1
            path.addFirst (v1);
            path.addLast (weightSum.get (v2));
        } // if path found
        else
            path.addLast (-1.0);
        return path;
    } // method findShortestPath

 
    protected class VertexWeightPair implements Comparable<VertexWeightPair>
    {
        Vertex vertex; 
        double weight;

        /**
         * Initializes this VertexWeightPair from vertex and weight.
         *
         */
        public VertexWeightPair (Vertex vertex, double weight)
        {
            this.vertex = vertex;
            this.weight = weight;
        } // default constructor

        /**
         *  Returns an int <, = or > 0 , depending on whether this VertexWeightPair's 
         *  weight is <, = or > other's weight.
         *
         */
        public int compareTo (VertexWeightPair other)
        {
            return (int)(weight - other.weight);
        } // method compareTo

        /**
         *  Returns a String representation of this VertexWeightPair.
         *
         */
        public String toString()
        {
            return vertex.toString() + "  " + String.valueOf (weight);
        } // method toString

    } // class VertexWeightPair  
    
    

    
    
} // class Network
