/* EX1
Suppose we are given the name and division number for each employee in a company.
There are no duplicate names. We would like to store this information alphabetically, by name. 
How should this be done? 
TreeMap? TreeSet? Comparable? Comparator? 
*/

import java.util.*;

class CompanyMap
{
    public static void main(String[ ] args)
    {

	TreeMap<String, Integer> companyMap = 
		new TreeMap<String, Integer>();

        companyMap.put ("Misino John", 8);
        companyMap.put ("Nguyen Viet", 14);
        companyMap.put ("Panchenko Eric", 6);
        companyMap.put ("Dunn Michael", 6);
        companyMap.put ("Deusenbery Amanda", 14);
        companyMap.put ("Taoubina Xenia", 6);

        System.out.println ("\nCompany:\n" + companyMap);

	System.out.println ("\nDivision number 6:\n");
	
	// ITERAZIONE SULLA COLLECTION VIEW!
	
	for (Map.Entry<String, Integer> entry : companyMap.entrySet()) {
		// entry � una specifica coppia chiave-valore <k,v>  
	    if (entry.getValue() == 6)  System.out.println (entry);
	}

    	System.out.println ("\nEmployees:\n" + companyMap.keySet());

    	System.out.println ("\nDivision numbers:\n" + new TreeSet<Integer>(companyMap.values()));

        /***  continua...  ***/

        // <Division number, number of employees> 
	TreeMap<Integer, Integer> companyCount =  new TreeMap<Integer, Integer>();

	for (Integer dn : companyMap.values())
	    companyCount.put(dn,0);  // inserisce <6,0>, <8,0>, <14, 0>

	for (Map.Entry<String, Integer> entry : companyMap.entrySet())
	    companyCount.put(entry.getValue(), companyCount.get(entry.getValue())+1 ); 

	System.out.println (companyCount);


    } // method main                                   
    

} // class CompanyMap
